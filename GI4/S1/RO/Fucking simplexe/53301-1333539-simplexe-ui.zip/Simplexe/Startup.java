import java.io.IOException;

import views.Simplexe;

/**
 * Lance l'application. 
 *
 */

public class Startup {

	public static void main(String arg[]) throws IOException{
		new Simplexe().setVisible(true);
	}
}
