-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Delete a single member of a redo log group
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
DECLARE
  v_cmd varchar2(300);
  v_count number;
BEGIN
  select '/bin/rm -f '||trim(member) into v_cmd from (select rownum "NUM", member from v$logfile where group#=(select group# from v$log where status = 'CURRENT') order by rownum) where num=1;
  execcmd(v_cmd);
  select count(*) into v_count from v$log;
  dbms_output.put_line(v_cmd);
  dbms_output.put_line(v_count);
--
-- Cycle through the log groups so that the group with the missing member is used at least once.
--   This ensures there will be an error message in the alert log 
  FOR i in 1..v_count LOOP
     execute immediate 'alter system switch logfile';
  END LOOP;
END;
/

 