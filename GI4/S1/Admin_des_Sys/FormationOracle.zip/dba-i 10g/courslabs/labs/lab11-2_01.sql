EXEC DBMS_FGA.ADD_POLICY(object_schema =>'hr',      -
object_name => 'employees', policy_name =>'chk_hr_emp',  -
audit_condition => '1=1', audit_column => 'salary');
