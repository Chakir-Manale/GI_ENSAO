# Oracle Database 10g: Administration Workshop I classroom script
# ***Training purposes only***
# ***Not appropriate for production use***
#
# Start a second session that will lock a row in HR's EMPLOYEES table
#
# Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
#
echo got this far
sqlplus smavris/oracle1# @$HOME/labs/lab17_01_b.sql