-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Moves the table hr.employees from one location to another. This
--   helps fix any migrated rows, as well as compacting unused space
--   in the segment that may have been caused by deleting data.
--
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
alter table hr.employees move;

