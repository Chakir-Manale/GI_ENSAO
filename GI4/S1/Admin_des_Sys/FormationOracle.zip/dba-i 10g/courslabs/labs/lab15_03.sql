-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Increase the size of HR's EMPLOYEES table
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
begin
  execute immediate 'alter table hr.employees enable row movement';
--
-- This is a PL/SQL loop, it will execute the enclosed statements 5 times
  FOR i IN 1..5 LOOP
    execute immediate 'alter table hr.employees allocate extent';
  END LOOP;
--
-- Gather statistics on the table so the database knows it has grown.
  dbms_stats.gather_schema_stats('HR');
end;
/