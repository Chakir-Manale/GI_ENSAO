-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Lock a row in HR's EMPLOYEES table
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
-- Because Nancy Greenberg has already locked this record, this statement
--   will appear to "hang" as it waits for Nancy to either commit or rollback.
show user
update hr.employees set phone_number='650.555.1212' where employee_id = 110;
--
-- The show user and prompt commands are SQL*Plus commands rather than SQL commands. 
--    Notice that they do not have to be ented with a semicolon
show user
prompt John Chen's record has been updated successfully.