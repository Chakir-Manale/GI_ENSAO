col INSTANCE_STATUS format a65
col USERNAME format a10
select Trim((select user from dual))||' is logged on to '||trim(instance_name)||' which is '||decode(status, 'STARTED', 'NOMOUNT', status)||' on '||host_Name "INSTANCE_STATUS" from v$instance
/                                              
