begin
execute immediate 'create table hr.inventory as select * from sh.sales';
for i in 1..4000 LOOP
execute immediate 'select * from hr.inventory';
execute immediate 'delete from hr.inventory';
execute immediate 'commit';
execute immediate 'insert into hr.inventory select * from sh.sales';
execute immediate 'commit';
END LOOP;
END;
/
