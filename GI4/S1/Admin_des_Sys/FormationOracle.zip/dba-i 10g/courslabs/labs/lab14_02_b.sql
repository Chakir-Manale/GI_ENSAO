-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Adds a row to HR's EMPLOYEES table.
--
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
INSERT INTO hr.employees VALUES (301, 'John','JONES','john.jones',
                 '650.555.1212',sysdate,'SH_CLERK',1234,0,101,50);
