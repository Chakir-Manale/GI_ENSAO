-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create a value-based audit trigger to capture changes to the salary
-- column of HR's EMPLOYEES table.
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
CREATE OR REPLACE TRIGGER SYSTEM.HRSALARY_AUDIT
    AFTER UPDATE OF SALARY
    ON HR.EMPLOYEES 
    REFERENCING NEW AS NEW OLD AS OLD 
    FOR EACH ROW  
BEGIN
-- Only capture changes if a change has been made to the salary column
   IF :OLD.salary != :NEW.salary THEN
--
-- Insert information about the change into a pre-created holding table. Capture
--     The operating system username of the person who made the change
--     The IP address the change was made from (to trace it back to a particular workstation)
--     The primary key (employee ID) of the record that was changed
--     The original and changed value for SALARY
   insert into system.audit_employees  
     values (sys_context('USERENV','OS_USER'), sysdate, 
     sys_context('USERENV','IP_ADDRESS'),
     :NEW.employee_id ||' Salary changed from '||:OLD.salary||' to '||:NEW.salary);
   END IF; 
END;
/
