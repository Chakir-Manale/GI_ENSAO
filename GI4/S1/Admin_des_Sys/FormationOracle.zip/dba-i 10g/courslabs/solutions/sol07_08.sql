-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Test idle timeout
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect rpandya/oracle
select systimestamp from dual;
prompt After about 15 minutes, try a select statement, it should fail due
prompt to idle session timeout settings.
