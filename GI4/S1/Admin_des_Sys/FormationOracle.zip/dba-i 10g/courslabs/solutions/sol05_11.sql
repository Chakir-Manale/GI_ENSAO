-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- View intialization parameters
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
col name format a29
col value format a70
set pages 300
set lines 100
SELECT name, value 
FROM v$parameter;
cle col
