-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create an index to improve data access
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
CREATE INDEX INVENTORY.OBSPROD_PRODNAME_IDX ON INVENTORY.OBSOLETE_PRODUCTS (PRODUCT_NAME);
