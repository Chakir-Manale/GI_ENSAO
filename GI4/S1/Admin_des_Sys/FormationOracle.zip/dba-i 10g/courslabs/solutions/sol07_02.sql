-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create roles and grant permissions to them
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
create role hrclerk;
grant select on hr.employees to hrclerk;
grant update on hr.employees to hrclerk;
create role hrmanager;
grant insert on hr.employees to hrmanager;
grant delete on hr.employees to hrmanager;
grant hrclerk to hrmanager;

