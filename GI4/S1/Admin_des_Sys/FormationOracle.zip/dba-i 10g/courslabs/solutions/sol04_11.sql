-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Join multiple tables and filter the results of a query
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
SELECT last_name, department_name, state_province
FROM employees JOIN departments USING (department_id)
JOIN locations USING (location_id)
WHERE department_id=30;
