-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Modify a profile
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
alter profile default limit failed_login_attempts 4 password_lock_time 1/144;
col profile format a10
col limit format a20
select profile, resource_name, limit
from dba_profiles
order by 1,2;
cle col

