-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Fix unusable invalid indexes
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect hr/hr@orcl
@@$HOME/labs/lab14_02_a.sql
connect hr/hr@orcl
@@$HOME/labs/lab14_02_b.sql
connect / as sysdba
select index_name, status from dba_indexes where owner='HR' order by 2,1;
alter index hr.EMP_DEPARTMENT_IX rebuild;
alter index hr.EMP_EMAIL_UK rebuild;
alter index hr.EMP_EMP_ID_PK rebuild;
alter index hr.EMP_JOB_IX rebuild;
alter index hr.EMP_MANAGER_IX rebuild;
alter index hr.EMP_NAME_IX rebuild;
select index_name, status from dba_indexes where owner='HR' order by 2,1;
connect hr/hr@orcl
@@$HOME/labs/lab14_02_b.sql
commit;
