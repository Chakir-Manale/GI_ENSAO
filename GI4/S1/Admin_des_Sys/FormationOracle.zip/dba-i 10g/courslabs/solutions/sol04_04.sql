-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Select from a table.
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
SELECT last_name, phone_number, department_id
FROM employees;