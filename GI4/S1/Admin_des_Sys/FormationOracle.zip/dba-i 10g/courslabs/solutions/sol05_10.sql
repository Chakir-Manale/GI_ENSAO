-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- View the alert log
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
host tail -75 /u01/app/oracle/admin/orcl/bdump/alert_orcl.log
