-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- View information about tables
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect system/oracle
col owner format a10
col table_name format a15
col tablespace_name format a16
select owner, table_name, tablespace_name, partitioned, num_rows, last_analyzed
from dba_tables
where owner='INVENTORY';
cle col
