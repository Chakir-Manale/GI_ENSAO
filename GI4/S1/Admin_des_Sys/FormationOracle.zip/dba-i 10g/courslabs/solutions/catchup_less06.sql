-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 6
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 6
connect / as sysdba
create tablespace inventory
datafile '/u01/app/oracle/oradata/orcl/inventory01.dbf' size 50M autoextend off segment space management auto;
