-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Join two tables together in a select statement
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
SELECT last_name, phone_number, department_name
FROM employees 
JOIN departments USING (department_id);
