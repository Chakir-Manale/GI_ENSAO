-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create users and grant roles to them
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
create user dhamby identified by newuser 
profile hrprofile password expire;
grant connect, hrclerk to dhamby;

create user rpandya identified by newuser 
profile hrprofile password expire;
grant connect, hrclerk to rpandya;

create user jgoodman identified by newuser 
profile hrprofile password expire;
grant connect, hrmanager to jgoodman;