-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Recover from loss of a controlfile
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
@@$HOME/labs/lab20_01_a.sql
@@$HOME/labs/lab20_01_b.sql
connect / as sysdba
shutdown abort
startup
pause Press any key to continue
host tail -10 /u01/app/oracle/admin/orcl/bdump/aler*
prompt Notice that the database crashed, we attempted to restart and failed to mount.
prompt A check of the alert log shows that a controlfile is missing.
pause Press any key to continue
host cp /u01/app/oracle/oradata/orcl/control01.ctl  /u01/app/oracle/oradata/orcl/control02.ctl
prompt Now the controlfile has been restored so we can mount the instance
pause press any key to continue
alter database mount;
alter database open;


