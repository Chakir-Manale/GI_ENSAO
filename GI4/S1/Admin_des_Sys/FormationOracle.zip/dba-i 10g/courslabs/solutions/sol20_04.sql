-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Recover from loss of a system or undo datafile
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
@@$HOME/labs/lab20_04.sql
connect / as sysdba
shutdown abort
startup
host rman target / nocatalog @$HOME/labs/lab20_04.rmn
alter database open;
select status from v$instance;
