-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 7
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 7
connect / as sysdba
create profile hrprofile limit idle_time 15;
create role hrclerk;
grant select on hr.employees to hrclerk;
grant update on hr.employees to hrclerk;
create role hrmanager;
grant insert on hr.employees to hrmanager;
grant delete on hr.employees to hrmanager;
grant hrclerk to hrmanager;
create user dhamby identified by newuser 
profile hrprofile password expire;
grant connect, hrclerk to dhamby;
create user rpandya identified by newuser 
profile hrprofile password expire;
grant connect, hrclerk to rpandya;
create user jgoodman identified by newuser 
profile hrprofile password expire;
grant connect, hrmanager to jgoodman;
alter user dhamby identified by oracle;
alter user jgoodman identified by oracle;
alter user rpandya identified by oracle;
create user inventory identified by verysecure
default tablespace inventory;
grant connect, resource to inventory;
