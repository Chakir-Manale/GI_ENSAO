-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 5
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 5
host emctl stop dbconsole
host isqlplusctl stop
host lsnrctl stop
host lsnrctl start
host emctl start dbconsole
host isqlplusctl start
connect / as sysdba
startup force

