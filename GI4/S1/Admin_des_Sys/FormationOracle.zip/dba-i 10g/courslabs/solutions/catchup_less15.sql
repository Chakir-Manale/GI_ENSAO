-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 15
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 15
connect / as sysdba
BEGIN DBMS_SERVER_ALERT.SET_THRESHOLD(9000,4,'70',4,'75',1,1,NULL,5,'INVENTORY'); 
END;
/
create table hr.filler tablespace inventory as select * from hr.employees;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
commit;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
commit;
commit;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
commit;
BEGIN DBMS_SERVER_ALERT.SET_THRESHOLD(9000,4,'70',4,'75',1,1,NULL,5,'INVENTORY'); 
END;
/
CONNECT hr/hr@orcl
@@$HOME/labs/lab15_03.sql
connect / as sysdba
variable id number;
variable name varchar2(500;
begin
  declare
  name varchar2(100);
  descr varchar2(500);
  obj_id number;
  begin
  name:='';
  descr:='Segment Advisor';
  dbms_advisor.create_task('Segment Advisor', :id, name, descr, NULL);
  dbms_advisor.create_object
     (name, 'TABLE', 'HR', 'EMPLOYEES', NULL, NULL, obj_id);
 dbms_advisor.set_task_parameter(name, 'RECOMMEND_ALL', 'TRUE');
 dbms_advisor.execute_task(name);
 end;
 end; 
 /
alter table "HR"."EMPLOYEES" shrink space COMPACT;
