-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Implement a standard password control scheme. View information about profiles
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
@@?/rdbms/admin/utlpwdmg.sql
col profile format a10
col limit format a20
select profile, resource_name, limit
from dba_profiles
order by 1,2;
cle col

