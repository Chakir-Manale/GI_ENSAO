-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Enable shared server connections
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
alter system set dispatchers='(protocol=tcp)(service=sharedorcl)';

