-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Verify there are at least two controlfiles
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
Select name from v$controlfile;