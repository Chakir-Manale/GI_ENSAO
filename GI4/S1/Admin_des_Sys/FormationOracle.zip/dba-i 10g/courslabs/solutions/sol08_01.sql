-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create a table with a check constraint and primary key
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
CREATE TABLE INVENTORY.PRODUCT_MASTER
   (    PRODUCT_ID NUMBER(5,0),
        PRODUCT_NAME VARCHAR2(50) NOT NULL ENABLE,
        CODE VARCHAR2(20) NOT NULL ENABLE,
        REORDER_THRESHOLD NUMBER(5,0),
        COST NUMBER(5,2),
        PRICE NUMBER(5,2),
        CONSTRAINT PRODMASTER_REORDTHRESH_CK CHECK (REORDER_THRESHOLD>0) ENABLE,
        CONSTRAINT PRODMASTER_PRODID_PK PRIMARY KEY (PRODUCT_ID)
    ) 
TABLESPACE INVENTORY;

