-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- View information about tablespaces
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
set linesize 150
set pagesize 100
col TABLESPACE_NAME format a20
col SIZE_MB format 999,999.999
col USED_PCT  format 999.99

select tablespace_name, contents, size_mb, used_pct from dba_tablespaces join 
(select tablespace_name, sum(TOTAL_SPACE)/(1024*1024) "SIZE_MB", sum(USED_SPACE)*100/sum(TOTAL_SPACE) "USED_PCT"
from (select a.tablespace_name, sum(a.bytes) "TOTAL_SPACE", 0 "USED_SPACE"
from dba_data_files a
group by a.tablespace_name
union
select c.tablespace_name, sum(c.bytes) "TOTAL_SPACE", 0 "USED_SPACE"
from dba_temp_files c
group by c.tablespace_name
union
select b.tablespace_name,0, sum(b.bytes) "USED_SPACE"
from dba_segments b
group by b.tablespace_name)
group by rollup(tablespace_name))
using (tablespace_name)
order by tablespace_name
/
set linesize 80
set pagesize 24
cle col