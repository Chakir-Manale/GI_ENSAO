-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Describe schema objects
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt employees
describe employees
prompt departments
describe departments
prompt locations
describe locations