-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Cause a lock conflict
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This session will appear to hang because of the lock conflict. In a separate terminal
prompt window you should run $HOME/solutions/sol17_02.sql
@$HOME/labs/lab17_01.sql
prompt You will need to open another terminal window to proceed with step 02 of this lab.