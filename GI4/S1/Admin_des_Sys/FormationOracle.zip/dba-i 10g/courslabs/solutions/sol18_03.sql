-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Shift the database to archive log mode
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
host mkdir /u01/app/oracle/archive
alter system set log_archive_dest_1='LOCATION=/u01/app/oracle/archive/';
shutdown immediate;
startup mount;
alter database archivelog;
alter database open;
archive log list;

