-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Set alert thresholds, fill a tablespace above the threshold, and observe the alert.
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
BEGIN DBMS_SERVER_ALERT.SET_THRESHOLD(9000,4,'70',4,'75',1,1,NULL,5,'INVENTORY'); 
END;
/
create table hr.filler tablespace inventory as select * from hr.employees;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
commit;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
commit;
commit;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
insert into hr.filler select * from hr.filler;
coommit;
set linesize 150
set pagesize 100
col TABLESPACE_NAME format a20
col SIZE_MB format 999,999.999
col USED_PCT  format 999.99

select tablespace_name, contents, size_mb, used_pct from dba_tablespaces join 
(select tablespace_name, sum(TOTAL_SPACE)/(1024*1024) "SIZE_MB", sum(USED_SPACE)*100/sum(TOTAL_SPACE) "USED_PCT"
from (select a.tablespace_name, sum(a.bytes) "TOTAL_SPACE", 0 "USED_SPACE"
from dba_data_files a
group by a.tablespace_name
union
select c.tablespace_name, sum(c.bytes) "TOTAL_SPACE", 0 "USED_SPACE"
from dba_temp_files c
group by c.tablespace_name
union
select b.tablespace_name,0, sum(b.bytes) "USED_SPACE"
from dba_segments b
group by b.tablespace_name)
group by rollup(tablespace_name))
using (tablespace_name)
where tablespace_name='USERS'
/
set linesize 80
set pagesize 24
cle col

select 'Current server time is: '||systimestamp from dual;

prompt The database will not detect the alert situation immediately because the
prompt monitoring process is low priority. If the next statement fails to
prompt detect the alert condition, wait about 5 minutes and re-execute
prompt the query by pressing / <enter>. You may need to wait as long as 15 minutes
prompt to receive the alert. If you would like, proceed to the next step and after
prompt sufficient time has passed run the select statement:
prompt
pause select * from dba_outstanding_alerts


