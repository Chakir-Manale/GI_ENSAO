-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create a table with a primary and foreign key
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
CREATE TABLE INVENTORY.PRODUCT_ON_HAND ( 
ON_HAND_ID NUMBER(5), 
PRODUCT_ID NUMBER(5), 
QUANTITY NUMBER(5), 
WAREHOUSE_CITY VARCHAR2(30), 
CONSTRAINT PRODONHAND_ONHANDID_PK PRIMARY KEY (ON_HAND_ID) VALIDATE , 
CONSTRAINT PRODONHAND_PRODMASTER_FK FOREIGN KEY (PRODUCT_ID) REFERENCES INVENTORY.PRODUCT_MASTER (PRODUCT_ID) VALIDATE );


