-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 9
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 9
connect system/oracle

create directory oracles_home as '/home/oracle';

declare
  h1   NUMBER;
begin
     h1 := dbms_datapump.open(operation => 'EXPORT', job_mode => 'SCHEMA'); 
     dbms_datapump.set_parallel(handle => h1, degree => 1); 
     dbms_datapump.add_file(handle => h1, filename => 'hrexport.log', directory => 'ORACLES_HOME', filetype => 3); 
     dbms_datapump.set_parameter(handle => h1, name => 'KEEP_MASTER', value => 0); 
     dbms_datapump.metadata_filter(handle => h1, name => 'SCHEMA_EXPR', value => 'IN(''HR'')'); 
     dbms_datapump.set_parameter(handle => h1, name => 'ESTIMATE', value => 'BLOCKS'); 
     dbms_datapump.add_file(handle => h1, filename => 'hrexport.dmp', directory => 'ORACLES_HOME', filetype => 1); 
     dbms_datapump.set_parameter(handle => h1, name => 'INCLUDE_METADATA', value => 1); 
     dbms_datapump.set_parameter(handle => h1, name => 'DATA_ACCESS_METHOD', value => 'AUTOMATIC'); 
     dbms_datapump.start_job(handle => h1, skip_current => 0, abort_step => 0); 
     dbms_datapump.detach(handle => h1); 
  end;
/


host sqlldr control=/home/oracle/labs/lab09_04_a.ctl log=/home/oracle/load_prodmaster.log userid=system/oracle
host sqlldr control=/home/oracle/labs/lab09_04_f.ctl log=/home/oracle/load_prodonhand.log userid=system/oracle

connect system/oracle

declare
 h1   NUMBER;
 begin
      h1 := dbms_datapump.open(operation => 'IMPORT', job_mode => 'TABLE'); 
     dbms_datapump.set_parallel(handle => h1, degree => 1); 
     dbms_datapump.add_file(handle => h1, filename => 'hrimport.log', directory => 'ORACLES_HOME', filetype => 3); 
     dbms_datapump.set_parameter(handle => h1, name => 'KEEP_MASTER', value => 0); 
     dbms_datapump.add_file(handle => h1, filename => 'hrexport.dmp', directory => 'ORACLES_HOME', filetype => 1); 
     dbms_datapump.metadata_remap(handle => h1, name => 'REMAP_SCHEMA', old_value => 'HR', value => 'INVENTORY'); 
     dbms_datapump.metadata_filter(handle => h1, name => 'SCHEMA_EXPR', value => 'IN(''HR'')'); 
     dbms_datapump.metadata_filter(handle => h1, name => 'NAME_EXPR', value => 'IN(''DEPARTMENTS'',''EMPLOYEES'',''LOCATIONS'')'); 
     dbms_datapump.set_parameter(handle => h1, name => 'DATA_ACCESS_METHOD', value => 'AUTOMATIC'); 
     dbms_datapump.set_parameter(handle => h1, name => 'INCLUDE_METADATA', value => 1); 
     dbms_datapump.set_parameter(handle => h1, name => 'SKIP_UNUSABLE_INDEXES', value => 0); 
     dbms_datapump.start_job(handle => h1, skip_current => 0, abort_step => 0); 
     dbms_datapump.detach(handle => h1); 
end;
/



