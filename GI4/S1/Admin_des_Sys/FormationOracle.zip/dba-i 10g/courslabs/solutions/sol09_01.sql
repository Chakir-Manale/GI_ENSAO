-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Use Data Pump to export a schema
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect system/oracle

create directory oracles_home as '/home/oracle';

declare
  h1   NUMBER;
begin
  begin 
      h1 := dbms_datapump.open (operation => 'EXPORT', job_mode => 'SCHEMA', job_name => 'hrexport1', version => 'COMPATIBLE'); 
  end;
  begin 
     dbms_datapump.set_parallel(handle => h1, degree => 1); 
  end;
  begin 
     dbms_datapump.add_file(handle => h1, filename => 'hrexport.log', directory => 'ORACLES_HOME', filetype => 3); 
  end;
  begin 
     dbms_datapump.set_parameter(handle => h1, name => 'KEEP_MASTER', value => 0); 
  end;
  begin 
     dbms_datapump.metadata_filter(handle => h1, name => 'SCHEMA_EXPR', value => 'IN(''HR'')'); 
  end;
  begin 
     dbms_datapump.set_parameter(handle => h1, name => 'ESTIMATE', value => 'BLOCKS'); 
  end;
  begin 
     dbms_datapump.add_file(handle => h1, filename => 'hrexport.dmp', directory => 'ORACLES_HOME', filetype => 1); 
  end;
  begin 
     dbms_datapump.set_parameter(handle => h1, name => 'INCLUDE_METADATA', value => 1); 
  end;
  begin 
     dbms_datapump.set_parameter(handle => h1, name => 'DATA_ACCESS_METHOD', value => 'AUTOMATIC'); 
  end;
  begin 
     dbms_datapump.start_job(handle => h1, skip_current => 0, abort_step => 0); 
  end;
  begin 
     dbms_datapump.detach(handle => h1); 
  end;
end;
/
