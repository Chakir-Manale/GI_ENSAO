-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Undo a transaction
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
ROLLBACK;