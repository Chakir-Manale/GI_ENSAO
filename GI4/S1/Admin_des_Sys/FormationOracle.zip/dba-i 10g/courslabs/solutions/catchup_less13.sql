-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 13
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 13
alter system set dispatchers='(protocol=tcp)(service=sharedorcl)';
