-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Start the iSQL*PLus listener
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
host isqlplusctl start
