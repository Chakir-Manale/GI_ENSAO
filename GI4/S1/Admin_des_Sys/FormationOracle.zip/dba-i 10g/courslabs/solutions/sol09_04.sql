host sqlldr control=/home/oracle/labs/lab09_04_a.ctl log=/home/oracle/load_prodmaster.log userid=system/oracle
host sqlldr control=/home/oracle/labs/lab09_04_f.ctl log=/home/oracle/load_prodonhand.log userid=system/oracle

