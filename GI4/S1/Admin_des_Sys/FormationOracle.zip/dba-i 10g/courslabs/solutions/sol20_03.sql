-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Recover from loss of a non-system/undo datafile
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
@@$HOME/labs/lab20_03.sql
select count(*) from HR.COUNTRIES;
prompt We appear to be missing one of the datafiles in the
prompt tablespace that contains HR's countries file!
alter tablespace example offline immediate;
pause Press any key to continue
host ls -l /u01/app/oracle/oradata/orcl/
prompt A check of the OS reveals the file is missing but the disk is still there
pause Press any key to continue
host rman target / nocatalog @$HOME/labs/lab20_03.rmn
prompt Now we have restored the missing file from backup:
host ls -l /u01/app/oracle/oradata/orcl/
pause Press any key to continue
select count(*) from HR.COUNTRIES;
