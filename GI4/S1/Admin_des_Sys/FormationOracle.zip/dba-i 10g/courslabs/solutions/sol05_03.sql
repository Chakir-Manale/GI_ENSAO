-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Shutdown the databse instance
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
shutdown immediate;
