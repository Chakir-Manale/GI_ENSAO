-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 11
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 11
connect / as sysdba
@@?/rdbms/admin/utlpwdmg.sql
alter profile default limit failed_login_attempts 4 password_lock_time 1/144;
CREATE PROFILE HREXEMPTPROFILE LIMIT CPU_PER_SESSION UNLIMITED
	CPU_PER_CALL UNLIMITED
	CONNECT_TIME UNLIMITED
	IDLE_TIME UNLIMITED
	SESSIONS_PER_USER UNLIMITED
	LOGICAL_READS_PER_SESSION UNLIMITED
	LOGICAL_READS_PER_CALL UNLIMITED
	PRIVATE_SGA UNLIMITED
	COMPOSITE_LIMIT UNLIMITED
	PASSWORD_LIFE_TIME UNLIMITED
	PASSWORD_GRACE_TIME 10
	PASSWORD_REUSE_MAX UNLIMITED
	PASSWORD_REUSE_TIME 1800
	PASSWORD_LOCK_TIME .0069
	FAILED_LOGIN_ATTEMPTS 4
	PASSWORD_VERIFY_FUNCTION VERIFY_FUNCTION;
alter user hr profile hrexemptprofile;
connect / as sysdba
alter system set audit_Trail=db scope=spfile;
startup force
audit SESSION whenever not successful;
connect hr/wrong_password@orcl
connect / as sysdba
exec DBMS_FGA.ADD_POLICY(object_schema =>'hr', object_name => 'employees', policy_name =>'chk_hr_emp', audit_condition => '1=1', audit_column => 'salary');
connect hr/hr@orcl
select last_name, first_name, phone_number from employees where employee_id=100;
select last_name, first_name, salary from employees where employee_id = 100;
connect system/oracle
create table audit_employees (who varchar2(10), event_date date, ipaddress varchar2(16), what varchar2(2000));
CREATE OR REPLACE TRIGGER SYSTEM.HRSALARY_AUDIT
    AFTER UPDATE OF SALARY
    ON HR.EMPLOYEES 
    REFERENCING NEW AS NEW OLD AS OLD 
    FOR EACH ROW  
BEGIN
-- Only capture changes if a change has been made to the salary column
   IF :OLD.salary != :NEW.salary THEN
--
-- Insert information about the change into a pre-created holding table. Capture
--     The operating system username of the person who made the change
--     The IP address the change was made from (to trace it back to a particular workstation)
--     The primary key (employee ID) of the record that was changed
--     The original and changed value for SALARY
   insert into system.audit_employees  
     values (sys_context('USERENV','OS_USER'), sysdate, 
     sys_context('USERENV','IP_ADDRESS'),
     :NEW.employee_id ||' Salary changed from '||:OLD.salary||' to '||:NEW.salary);
   END IF; 
END;
/
connect hr/hr@orcl
UPDATE employees SET salary=salary+100 WHERE employee_id=100;
connect / as sysdba
