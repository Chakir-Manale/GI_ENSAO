-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- View information about data files
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
col tablespace_name format a20
col file_name format a45
select file_name, tablespace_name, bytes, autoextensible, maxbytes
from dba_data_files;
cle col

