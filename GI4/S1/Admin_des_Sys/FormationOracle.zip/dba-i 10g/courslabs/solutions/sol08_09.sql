-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Add a column to an existing table
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
ALTER TABLE INVENTORY.OBSOLETE_PRODUCTS ADD (OBSOLETED DATE);