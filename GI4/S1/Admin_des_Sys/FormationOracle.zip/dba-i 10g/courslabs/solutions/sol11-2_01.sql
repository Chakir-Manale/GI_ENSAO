-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Implement fine grained auditing
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect system/oracle
exec DBMS_FGA.ADD_POLICY(object_schema =>'hr', object_name => 'employees', policy_name =>'chk_hr_emp', audit_condition => '1=1', audit_column => 'salary');
connect hr/hr@orcl
select last_name, first_name, phone_number from employees where employee_id=100;
select last_name, first_name, salary from employees where employee_id = 100;
col db_user format a8
col os_user format a8
col sql_text format a51
set lines 75
select db_user, os_user, sql_text from dba_fga_audit_trail;
cle col


