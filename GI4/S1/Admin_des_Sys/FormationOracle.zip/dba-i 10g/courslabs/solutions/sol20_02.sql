-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Recover from loss of a redo log member in a multi-member group
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This first step may take up to five minutes.
@@$HOME/labs/lab20_02.sql
host ls -l /u01/app/oracle/oradata/orcl/*.log
pause You should be missing one of your log files.

DECLARE
  v_sql varchar2(300);
  v_current number;
BEGIN
  select group# into v_current from v$log where status='CURRENT';
  IF v_current=1 THEN
     execute immediate 'alter system switch logfile';
  ELSE
  v_sql:= 'alter database clear logfile group 1';
  dbms_output.put_line(v_sql);
  execute immediate v_sql;
END;
/
prompt The missing logfile was fixed by clearing the 
pause logfile group 
host ls -l /u01/app/oracle/oradata/orcl/*.log

