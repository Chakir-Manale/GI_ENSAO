-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Modify existing data, use a filtering condition
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
UPDATE employees 
SET salary=salary*1.1
WHERE department_id=80;
