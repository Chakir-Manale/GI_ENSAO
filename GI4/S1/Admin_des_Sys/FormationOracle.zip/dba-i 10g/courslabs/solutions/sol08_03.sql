-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create a table with a primary key (for later practice in deleting a table)
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
CREATE TABLE "INVENTORY"."OBSOLETE_PRODUCTS" ( 
"PRODUCT_ID" NUMBER(5), 
"PRODUCT_NAME" VARCHAR2(50) NOT NULL , 
"CODE" VARCHAR2(20) NOT NULL , 
"COST" NUMBER(5, 2), 
"PRICE" VARCHAR2(5), 
CONSTRAINT "OBSPROD_PRODID_PK" PRIMARY KEY ("PRODUCT_ID") VALIDATE );

