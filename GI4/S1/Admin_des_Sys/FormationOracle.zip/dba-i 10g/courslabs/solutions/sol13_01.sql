-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- View process consumption by the Oracle user. Verify shared servers are not in use.
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
host ps -ef|grep oracle|wc -l  
connect system/oracle@orcl
select * from v$circuit;
host ps -ef|grep oracle|wc -l 
