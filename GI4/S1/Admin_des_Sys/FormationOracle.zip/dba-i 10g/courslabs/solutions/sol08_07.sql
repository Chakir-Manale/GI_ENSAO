-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Add columns to an existing table
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
ALTER TABLE INVENTORY.PRODUCT_MASTER ADD ( 
PRIMARY_SOURCE VARCHAR2(50), 
SECONDARY_SOURCE VARCHAR2(50));

 
