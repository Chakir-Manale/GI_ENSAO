-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Automate common database management tasks
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
BEGIN
sys.dbms_scheduler.create_job( 
job_name => '"SYSTEM"."GATHERSTATSOEHR"',
job_type => 'PLSQL_BLOCK',
job_action => 'begin
dbms_stats.gather_schema_stats( 
ownname=> ''OE'', 
granularity=> ''DEFAULT'', 
block_sample=> FALSE, 
cascade=> TRUE, 
method_opt=> ''FOR COLUMNS SIZE AUTO'', 
options=> ''GATHER AUTO'');

dbms_stats.gather_schema_stats( 
ownname=> ''HR'', 
granularity=> ''DEFAULT'', 
block_sample=> FALSE, 
cascade=> TRUE, 
method_opt=> ''FOR COLUMNS SIZE AUTO'', 
options=> ''GATHER AUTO'');

end;',
repeat_interval => 'FREQ=DAILY;BYHOUR=1;BYMINUTE=0',
start_date => to_timestamp_tz('2004-01-27 -8:00', 'YYYY-MM-DD TZH:TZM'),
job_class => 'DEFAULT_JOB_CLASS',
comments => 'Automated Stats Job',
auto_drop => FALSE,
enabled => FALSE);
sys.dbms_scheduler.set_attribute( name => '"SYSTEM"."GATHERSTATSOEHR"', attribute => 'restartable', value => TRUE); 
sys.dbms_scheduler.enable( '"SYSTEM"."GATHERSTATSOEHR"' ); 
END;
/

