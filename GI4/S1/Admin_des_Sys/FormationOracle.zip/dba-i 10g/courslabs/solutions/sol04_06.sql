-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Join three tables together in a select statement
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
SELECT last_name, department_name, city
FROM employees 
JOIN departments USING (department_id)
JOIN locations USING (location_id);
