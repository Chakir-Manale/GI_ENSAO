-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- resize the undo tablespace to accomodate undo retention requirements
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
ALTER DATABASE DATAFILE '/u01/app/oracle/oradata/orcl/undotbs01.dbf' RESIZE 500M;
