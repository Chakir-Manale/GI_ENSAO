-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create an index on multiple columns
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
CREATE INDEX INVENTORY.PRODONHAND_PRODID_QTY_IDX  ON INVENTORY.PRODUCT_ON_HAND (PRODUCT_ID, QUANTITY);

