-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Make a connection using shared servers
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect system/oracle@localhost:1521/sharedorcl.oracle.com
select * from v$circuit;
host ps -ef|grep oracle|wc -l 
