-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Drop (delete) a table
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
DROP TABLE INVENTORY.OBSOLETE_PRODUCTS;
ALTER TABLE INVENTORY.PRODUCT_MASTER ADD (OBSOLETED DATE);
