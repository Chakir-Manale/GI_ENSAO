-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Stop Oracle Enterprise Manager's Database Control
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
host emctl stop dbconsole
