-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Set threshold for alerts
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
BEGIN DBMS_SERVER_ALERT.SET_THRESHOLD(9000,4,'70',4,'75',1,1,NULL,5,'INVENTORY'); 
END;
/