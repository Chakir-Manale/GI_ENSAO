-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create a view to join two tables together.
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
CREATE VIEW "INVENTORY"."WAREHOUSE_VW" AS SELECT product_name, quantity, warehouse_city 
FROM inventory.product_master 
JOIN inventory.product_on_hand 
USING (product_id);
