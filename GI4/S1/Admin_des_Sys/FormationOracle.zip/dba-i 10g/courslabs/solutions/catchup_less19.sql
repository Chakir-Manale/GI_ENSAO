-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 19
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 19
host mkdir /u01/app/oracle/backup
host rman target / nocatalog @$HOME/labs/lab19_01.rmn
host rman target / nocatalog @$HOME/labs/lab19_02.rmn
