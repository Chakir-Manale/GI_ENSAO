-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Test user connections. Note that these users have expired passwords
-- so you are asked to change them.
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
connect / as sysdba
alter user dhamby identified by oracle;
alter user jgoodman identified by oracle;
alter user rpandya identified by oracle;
connect dhamby/oracle
SELECT salary FROM hr.employees WHERE EMPLOYEE_ID=197;
DELETE FROM  hr.employees WHERE EMPLOYEE_ID=197;
connect jgoodman/oracle
SELECT salary FROM hr.employees WHERE EMPLOYEE_ID=197;
DELETE FROM  hr.employees WHERE EMPLOYEE_ID=197;
rollback;