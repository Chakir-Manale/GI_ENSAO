emctl stop dbconsole
isqlplusctl stop
lsnrctl stop
sqlplus "/ as sysdba" <<EOF
shutdown abort
exit
EOF
echo -------------------------------------------------------
echo -------------------------------------------------------
echo When prompted for a password, use "oracle." 
echo -------------------------------------------------------
echo -------------------------------------------------------
rm -rf $ORACLE_BASE/*
su - root -c "rm -rf /usr/local/bin/dbhome /usr/local/bin/coraenv /usr/local/bin/oraenv /etc/oratab /etc/oraInst.loc /etc/oracle; shutdown -r now"



