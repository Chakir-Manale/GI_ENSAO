-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Create a backup
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
host rman target / nocatalog @$HOME/labs/lab19_02.rmn
