-- Oracle Database 10g: Administration Workshop I classroom script
-- ***Training purposes only***
-- ***Not appropriate for production use***
--
-- Catchup for practice 16
--
-- Russ Lowenthal, Oracle Server Technologies (russ.lowenthal@oracle.com)
--
prompt This performs catch up steps for practice 16
connect / as sysdba
ALTER DATABASE DATAFILE '/u01/app/oracle/oradata/orcl/undotbs01.dbf' RESIZE 500M;
