/stage/Disk1/runInstaller -responseFile /home/oracle/labs/install.rsp -silent
read
echo -------------------------------------------------------
echo -------------------------------------------------------
echo When prompted for a password, use "oracle." 
echo When asked for the location of /usr/local/bin, just hit enter.
echo Enter to continue.
echo -------------------------------------------------------
echo -------------------------------------------------------
read
su - root -c "/u01/app/oracle/oraInventory/orainstRoot.sh; /u01/app/oracle/product/10.1.0/db_1/root.sh"
sqlplus "/ as sysdba" <<EOF
alter user hr identified by hr account unlock;
EOF


