REM #############################
REM
REM   CREATED:      30 Mar 2001
REM   UPDATED:      24 Apr 2001
REM   FILE NAME:    crdb2sid.sql
REM   FILE VERSION: 1.1.3
REM
REM	Modified 01-NOV-01 Monty Orme
REM		For use at OAEC Partner locations and NT On-istes
REM
REM
REM #############################


rem SET ECHO ON
rem SET TERMOUT ON

REM #################################
REM
REM	Run ordinst.sql to prep for Sample Schemas
REM
REM #################################

CONNECT / AS SYSDBA

@%ORACLE_HOME%\ord\admin\ordinst.sql

REM #################################
REM
REM 	Run mdinst.sql to prep for Sample Schemas
REM
REM #################################

CONNECT MDSYS/MDSYS

@%ORACLE_HOME%\md\admin\mdinst.sql

REM #################################
REM
REM Add Sample Schema Users HR and OE
REM
REM #################################

CONNECT / AS SYSDBA

@%ORACLE_HOME%\demo\schema\human_resources\hr_main.sql hr sample temp oracle c:\oraclass\admin\create\

CONNECT sys/change_on_install AS SYSDBA

DROP TRIGGER hr.secure_employees;

CONNECT / AS SYSDBA

@%ORACLE_HOME%\demo\schema\order_entry\oe_main.sql oe sample temp hr oracle c:\oraclass\admin\create\

SPOOL %CLASS_HOME%\ADMIN\CREATE\credb2.log

SET ECHO ON

CONNECT / AS SYSDBA

ALTER USER hr
QUOTA unlimited ON query_data;

CREATE TABLE hr.employees_hist
TABLESPACE query_data
AS SELECT * FROM hr.employees;

CREATE TABLE hr.departments_hist
TABLESPACE query_data
AS SELECT * FROM hr.departments;

ALTER TABLESPACE query_data READ ONLY;

SPOOL OFF

exit


 
