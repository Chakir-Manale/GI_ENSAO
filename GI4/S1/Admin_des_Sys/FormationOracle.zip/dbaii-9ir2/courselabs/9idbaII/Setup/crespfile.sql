spool %CLASS_HOME%\admin\create\crespfile.log
set echo on
create spfile='spfiledba.ora'
from pfile='initdba.ora';
set echo off
spool off
exit




