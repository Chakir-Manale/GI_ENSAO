REM #############################
REM
REM   CREATED:      28 Feb 2001
REM   UPDATED:      18 Apr 2001
REM   FILE NAME:    crdb1sid.sql
REM   FILE VERSION: 1.1.3
REM
REM
REM	Modified 01-NOV-01 Monty Orme
REM		For use at OAEC Partner locations and NT On-sites
REM
REM #############################

SPOOL %CLASS_HOME%\ADMIN\CREATE\credb1.log

SET ECHO ON

REM ***** Tablespace for User *****
CREATE TABLESPACE users
   DATAFILE 'c:\oraclass\ORADATA\u03\users01.dbf' SIZE 5M
   PERMANENT
   EXTENT MANAGEMENT LOCAL UNIFORM SIZE 32K
   SEGMENT SPACE MANAGEMENT AUTO;

REM ***** Tablespace for Index *****
CREATE TABLESPACE indx
   DATAFILE 'c:\oraclass\ORADATA\u03\indx01.dbf' SIZE 5M
   PERMANENT
   EXTENT MANAGEMENT LOCAL UNIFORM SIZE 500K
   SEGMENT SPACE MANAGEMENT AUTO;

REM **** Sample Schema ****
CREATE TABLESPACE sample
   DATAFILE 'c:\oraclass\ORADATA\u02\sample01.dbf' size 10M
   AUTOEXTEND ON NEXT 10M MAXSIZE 250M
   PERMANENT
   EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M;

REM ***** Read Only Tablespace *****
CREATE TABLESPACE query_data
   DATAFILE 'c:\oraclass\ORADATA\u01\querydata01.dbf' SIZE 1M
   PERMANENT
   EXTENT MANAGEMENT LOCAL UNIFORM SIZE 48K
   SEGMENT SPACE MANAGEMENT AUTO;

ALTER USER sys 
TEMPORARY TABLESPACE temp;

spool off
set echo off

@%ORACLE_HOME%\rdbms\admin\catalog.sql
@%ORACLE_HOME%\rdbms\admin\catproc.sql

CONNECT system/manager
@%ORACLE_HOME%\sqlplus\admin\pupbld.sql

exit


 
