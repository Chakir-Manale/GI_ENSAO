ALTER DATABASE CREATE DATAFILE
'c:\oraclass\ORADATA\u04\newusers01.dbf'
/


