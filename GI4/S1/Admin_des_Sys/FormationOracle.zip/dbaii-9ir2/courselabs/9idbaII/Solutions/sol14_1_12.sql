host net stop oracleserviceDBA
host xcopy c:\oraclass\BACKUP\UMAN\*.dbf c:\oraclass\oradata /s
host net start oracleserviceDBA