connect system/manager
SELECT f.file_name
FROM dba_tables t, dba_data_files f
WHERE table_name = 'EMPHIST' AND
t.tablespace_name = f.tablespace_name
/
