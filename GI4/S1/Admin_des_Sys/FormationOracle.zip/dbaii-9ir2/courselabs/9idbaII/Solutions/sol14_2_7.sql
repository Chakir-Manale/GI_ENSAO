host net stop oracleserviceDBA
host copy %CLASS_HOME%\BACKUP\UMAN\u04\users01.dbf %CLASS_HOME%\ORADATA\u04
host net start oracleserviceDBA
