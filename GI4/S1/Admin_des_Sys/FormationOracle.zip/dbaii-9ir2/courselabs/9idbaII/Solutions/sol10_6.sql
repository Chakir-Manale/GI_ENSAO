alter database backup controlfile
to 'c:\oraclass\BACKUP\UMAN\cntrl1.bkp'
/

