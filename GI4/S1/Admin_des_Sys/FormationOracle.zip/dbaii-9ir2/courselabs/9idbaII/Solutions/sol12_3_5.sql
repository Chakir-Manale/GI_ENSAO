ALTER TABLESPACE users OFFLINE IMMEDIATE
/
host copy %CLASS_HOME%\backup\uman\u03\users01.dbf %CLASS_HOME%\oradata\u03
