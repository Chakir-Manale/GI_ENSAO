set echo off
col name format a50
set echo on
select name from v$controlfile
/
select member from v$logfile
/
select name from v$datafile
/
set echo off
col name clear


