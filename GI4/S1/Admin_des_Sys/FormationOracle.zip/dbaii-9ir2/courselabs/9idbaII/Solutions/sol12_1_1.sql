connect sys/change_on_install as sysdba

shutdown immediate

connect sys/change_on_install as sysdba

startup mount

alter database noarchivelog
/

alter database open
/

archive log list

