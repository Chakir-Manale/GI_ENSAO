SELECT * FROM v$log
/
