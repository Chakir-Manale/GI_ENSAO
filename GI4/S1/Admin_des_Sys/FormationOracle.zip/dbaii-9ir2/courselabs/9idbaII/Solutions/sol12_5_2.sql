host copy %CLASS_HOME%\oradata\u02\sample01.dbf %CLASS_HOME%\backup\uman
