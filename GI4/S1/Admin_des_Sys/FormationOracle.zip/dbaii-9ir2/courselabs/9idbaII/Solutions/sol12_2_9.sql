host copy %CLASS_HOME%\backup\uman\u03\users01.dbf %CLASS_HOME%\ORADATA\u03\users01.dbf

