connect system/manager
SELECT * FROM v$log
/

