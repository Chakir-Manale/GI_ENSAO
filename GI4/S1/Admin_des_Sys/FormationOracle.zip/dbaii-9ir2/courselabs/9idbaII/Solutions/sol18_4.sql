select count(*) from hr.employees
/
select count(*) from hr.departments
/
