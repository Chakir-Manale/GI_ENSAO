SELECT COUNT(*) FROM emphist
/
