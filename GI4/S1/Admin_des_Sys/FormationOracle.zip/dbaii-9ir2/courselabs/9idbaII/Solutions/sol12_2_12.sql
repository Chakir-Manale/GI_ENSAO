SELECT tablespace_name, status
FROM dba_tablespaces
WHERE tablespace_name = 'USERS'
/
