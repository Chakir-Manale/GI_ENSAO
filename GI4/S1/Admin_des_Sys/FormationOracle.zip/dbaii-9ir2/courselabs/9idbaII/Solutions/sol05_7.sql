select name, status, circuit from v$shared_server
/

