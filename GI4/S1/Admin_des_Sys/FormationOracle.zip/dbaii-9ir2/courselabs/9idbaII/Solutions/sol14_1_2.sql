connect hr/hr

INSERT INTO emphist SELECT * FROM emphist
/
COMMIT
/

