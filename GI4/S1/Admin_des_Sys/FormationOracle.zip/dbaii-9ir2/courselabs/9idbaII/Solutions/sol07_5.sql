SELECT pid, username FROM v$process
/
