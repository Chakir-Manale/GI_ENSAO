alter system archive log stop
/
