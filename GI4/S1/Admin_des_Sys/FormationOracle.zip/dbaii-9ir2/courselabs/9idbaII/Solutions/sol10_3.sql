CONNECT sys/change_on_install as sysdba
startup 


