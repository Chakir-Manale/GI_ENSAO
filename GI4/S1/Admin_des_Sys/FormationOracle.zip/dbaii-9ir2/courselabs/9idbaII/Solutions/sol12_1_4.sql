SELECT f.file_name FROM dba_tables t,
dba_data_files f
WHERE table_name = 'EMPHIST' and
t.tablespace_name = f.tablespace_name
/
