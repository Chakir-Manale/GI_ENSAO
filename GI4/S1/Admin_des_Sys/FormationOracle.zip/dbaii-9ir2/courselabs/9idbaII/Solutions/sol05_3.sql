select circuit, dispatcher, server from v$circuit
/

