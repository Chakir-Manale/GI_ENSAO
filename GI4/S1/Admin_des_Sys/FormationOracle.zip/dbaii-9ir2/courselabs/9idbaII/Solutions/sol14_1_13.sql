connect sys/change_on_install as sysdba

startup mount 

recover database until time '2001-12-27:09:45:00'
