connect sys/change_on_install as sysdba

@%CLASS_HOME%\student\labs\emphist
@%CLASS_HOME%\student\labs\moreemphist
