select name, status from v$dispatcher
/

