SELECT name, db_name, file#
FROM rcuser.rc_datafile_copy
/
