connect sys/change_on_install as sysdba
select * from v$log;
select * from v$logfile;

