SELECT COUNT(*)
FROM hr.emphist
/
