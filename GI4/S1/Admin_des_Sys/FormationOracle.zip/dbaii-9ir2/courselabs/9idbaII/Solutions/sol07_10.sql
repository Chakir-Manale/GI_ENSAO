ALTER DATABASE ADD LOGFILE MEMBER
'c:\oraclass\oradata\u04\log01b.rdo' to GROUP 1,
'c:\oraclass\oradata\u04\log02b.rdo' to GROUP 2
/
