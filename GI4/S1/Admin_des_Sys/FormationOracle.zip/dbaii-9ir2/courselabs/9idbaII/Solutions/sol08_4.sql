show parameter log_archive
