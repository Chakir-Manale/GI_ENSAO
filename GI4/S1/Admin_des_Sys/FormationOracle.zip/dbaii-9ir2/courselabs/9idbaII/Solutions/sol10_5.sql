alter database backup controlfile to trace
/
