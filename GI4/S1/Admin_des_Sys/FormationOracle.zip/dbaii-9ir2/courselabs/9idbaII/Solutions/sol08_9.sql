alter system switch logfile
/
alter system switch logfile
/
col name format a30
col value format a45
SELECT name, value
FROM v$parameter
WHERE name LIKE 'log_archive%'
/

