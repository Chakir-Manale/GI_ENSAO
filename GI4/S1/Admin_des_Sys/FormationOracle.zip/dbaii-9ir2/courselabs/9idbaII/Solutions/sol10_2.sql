CONNECT sys/change_on_install as sysdba
shutdown immediate

