SELECT name FROM v$database
/
