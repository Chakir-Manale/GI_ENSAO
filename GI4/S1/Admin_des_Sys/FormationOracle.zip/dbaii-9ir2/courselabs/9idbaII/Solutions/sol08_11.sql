alter system switch logfile
/
alter system switch logfile
/

