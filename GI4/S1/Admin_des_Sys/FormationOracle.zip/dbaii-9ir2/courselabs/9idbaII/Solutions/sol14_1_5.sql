host date /t
host time /t


