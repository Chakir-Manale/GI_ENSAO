connect sys/change_on_install as sysdba

shutdown immediate

host xcopy /E c:\oraclass\oradata c:\oraclass\backup\noarch

connect sys/change_on_install as sysdba

startup 





