connect hr/hr
SELECT *
FROM emphist
/
