SELECt *
FROM v$log
/
