SELECT COUNT (*) FROM emphist
/
