SELECT * FROM v$backup
/
