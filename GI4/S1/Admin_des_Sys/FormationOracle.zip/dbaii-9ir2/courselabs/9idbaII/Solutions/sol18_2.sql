connect sys/change_on_install as sysdba
@?\rdbms\admin\catexp.sql

connect hr/hr
drop table employees cascade constraints
/
drop table departments cascade constraints
/
