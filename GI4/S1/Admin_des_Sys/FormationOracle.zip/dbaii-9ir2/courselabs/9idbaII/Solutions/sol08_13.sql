alter system archive log start
/
