SELECT * FROM hr.emphist
/
