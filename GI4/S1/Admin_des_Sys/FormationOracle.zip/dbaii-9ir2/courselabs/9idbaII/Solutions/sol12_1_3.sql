@emphist.sql
SELECT COUNT(*)
FROM HR.EMPHIST;





