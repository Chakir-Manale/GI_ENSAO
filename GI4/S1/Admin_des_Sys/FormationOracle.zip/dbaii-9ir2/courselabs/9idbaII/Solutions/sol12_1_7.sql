connect sys/change_on_install as sysdba
shutdown abort
host xcopy /E c:\oraclass\BACKUP\NOARCH c:\oraclass\ORADATA 



