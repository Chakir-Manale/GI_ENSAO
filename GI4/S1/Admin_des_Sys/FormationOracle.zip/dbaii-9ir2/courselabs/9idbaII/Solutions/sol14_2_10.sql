host net stop oracleserviceDBA
host copy %CLASS_HOME%\BACKUP\UMAN\u01\*.dbf %CLASS_HOME%\ORADATA\u01
host copy %CLASS_HOME%\BACKUP\UMAN\u02\*.dbf %CLASS_HOME%\ORADATA\u02
host copy %CLASS_HOME%\BACKUP\UMAN\u03\*.dbf %CLASS_HOME%\ORADATA\u03
host copy %CLASS_HOME%\BACKUP\UMAN\u04\*.dbf %CLASS_HOME%\ORADATA\u04
host net start oracleserviceDBA
