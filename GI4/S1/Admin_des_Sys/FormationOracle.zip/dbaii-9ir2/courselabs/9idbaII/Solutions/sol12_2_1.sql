connect sys/change_on_install as sysdba
SELECT dbid, name, log_mode
FROM v$database
/
archive log list;

