col name format a40
SELECT name, status FROM v$datafile
/
col name clear
