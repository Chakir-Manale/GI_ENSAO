SELECT count(*)
FROM hr.emphist
/
