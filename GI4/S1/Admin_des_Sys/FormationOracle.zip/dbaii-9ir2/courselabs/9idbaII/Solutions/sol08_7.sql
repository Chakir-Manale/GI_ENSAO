alter database open
/
