UPDATE hr.new_emp
SET salary = salary * 1.1
/
