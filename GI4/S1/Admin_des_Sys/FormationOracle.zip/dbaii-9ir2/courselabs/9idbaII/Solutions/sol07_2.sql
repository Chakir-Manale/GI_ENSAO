SELECT group#, status FROM v$log
/
SELECT member FROM v$logfile
/
