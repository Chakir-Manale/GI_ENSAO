alter database archivelog
/
