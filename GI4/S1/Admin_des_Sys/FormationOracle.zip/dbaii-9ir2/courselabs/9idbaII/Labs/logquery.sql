select 'rm -f' || al.name || ';'
from v$archived_log al, v$log l
where al.sequence# = l.sequence#
and l.status = 'INACTIVE'
/
