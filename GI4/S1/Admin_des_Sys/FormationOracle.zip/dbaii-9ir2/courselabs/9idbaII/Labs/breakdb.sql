connect system/manager
set head off
set feedback off
set echo off
alter system switch logfile;
@%CLASS_HOME%\STUDENT\LABS\moreemphist.sql
SELECT count(*) FROM hr.emphist;
connect system/manager
alter system switch logfile;
spool %CLASS_HOME%\STUDENT\LABS\breakdb.cmd
select 'del /q ' || file_name from dba_data_files
where tablespace_name = 'USERS';
spool off
alter system switch logfile;
host net stop oracleserviceDBA
host %CLASS_HOME%\STUDENT\labs\sleep 15
host %CLASS_HOME%\STUDENT\LABS\breakdb.cmd
host %CLASS_HOME%\STUDENT\labs\sleep 5
host net start oracleserviceDBA
set head on
set feedback on





