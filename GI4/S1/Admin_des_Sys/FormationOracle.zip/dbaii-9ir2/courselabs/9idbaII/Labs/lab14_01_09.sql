@%CLASS_HOME%\STUDENT\LABS\breaktab.sql
