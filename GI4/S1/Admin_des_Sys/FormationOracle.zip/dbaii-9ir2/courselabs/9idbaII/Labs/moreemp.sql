Rem  MORE_EMP to expand the size of the NEWEMP table.
Rem

INSERT INTO scott.newemp SELECT * FROM scott.newemp where rownum < 5;
COMMIT;
ALTER SYSTEM SWITCH LOGFILE;
INSERT INTO scott.newemp SELECT * FROM scott.newemp where rownum < 5;
COMMIT;
ALTER SYSTEM SWITCH LOGFILE;
INSERT INTO scott.newemp SELECT * FROM scott.newemp where rownum < 5;
COMMIT;
ALTER SYSTEM SWITCH LOGFILE;
COMMIT;
update scott.newemp set salary = salary + 1;
COMMIT;
ALTER SYSTEM SWITCH LOGFILE;
select count(*) from scott.newemp;   
