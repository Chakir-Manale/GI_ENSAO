connect sys/change_on_install as sysdba
alter system switch logfile;
alter system switch logfile;
set head off
set feedback off
@%CLASS_HOME%\STUDENT\LABS\moddb.sql
connect sys/change_on_install as sysdba



