@%CLASS_HOME%\STUDENT\LABS\moredata.sql
