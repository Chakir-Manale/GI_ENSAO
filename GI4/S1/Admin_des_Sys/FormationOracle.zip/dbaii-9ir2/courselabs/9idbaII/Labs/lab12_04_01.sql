@%CLASS_HOME%\STUDENT\LABS\newtbs.sql

