@%CLASS_HOME%\student\labs\emphist.sql







