@%CLASS_HOME%\STUDENT\LABS\crebkup.sql
