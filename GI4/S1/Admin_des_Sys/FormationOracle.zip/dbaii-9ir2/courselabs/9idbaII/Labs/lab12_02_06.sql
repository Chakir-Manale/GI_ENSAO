@%CLASS_HOME%\STUDENT\LABS\checktbs.sql

