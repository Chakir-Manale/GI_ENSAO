connect system/manager

create index emphist_lname_idx on hr.emphist (last_name)
tablespace indx;

