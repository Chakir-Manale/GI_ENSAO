@%CLASS_HOME%\STUDENT\LABS\breakdb.sql

