connect system/manager
alter system switch logfile;
drop table hr.emphist;
alter system switch logfile;
select username from user_users;
