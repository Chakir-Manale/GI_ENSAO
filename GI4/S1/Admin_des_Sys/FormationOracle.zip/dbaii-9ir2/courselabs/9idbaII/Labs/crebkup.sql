set head off
set feedback off
set echo off
spool %CLASS_HOME%\STUDENT\LABS\samplebkup.cmd
select 'copy ' || file_name || ' c:\oraclass\BACKUP\sample01.cpy' from dba_data_files
where tablespace_name = 'SAMPLE';
spool off
ALTER TABLESPACE sample BEGIN BACKUP;
host %CLASS_HOME%\STUDENT\LABS\samplebkup.cmd
ALTER TABLESPACE sample END BACKUP;
set head on
set feedback on
set echo on

