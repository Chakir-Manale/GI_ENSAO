connect scott/tiger
CREATE TABLE newemp 
TABLESPACE users 
AS SELECT * FROM emp;
