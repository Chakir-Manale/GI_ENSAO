set echo off
spool %CLASS_HOME%\STUDENT\LABS\breakarc.cmd
select 'del /q ' || name 
from v$archived_log al, v$log l
where al.sequence# = l.sequence#
  and l.status <> 'CURRENT'
/
spool off
alter system switch logfile;
host %CLASS_HOME%\STUDENT\LABS\breakarc.cmd


