Rem  MOREEMPHIST to increase the size of the EMPHIST table.
Rem

INSERT INTO hr.emphist SELECT * FROM hr.employees WHERE department_id = 10;
COMMIT;
ALTER SYSTEM SWITCH LOGFILE;
INSERT INTO hr.emphist SELECT * FROM hr.employees WHERE department_id = 20;
COMMIT;
ALTER SYSTEM SWITCH LOGFILE;
INSERT INTO hr.emphist SELECT * FROM hr.employees WHERE department_id = 30;
COMMIT;
ALTER SYSTEM SWITCH LOGFILE;
INSERT INTO hr.emphist SELECT * FROM hr.employees WHERE department_id = 40;
REM UPDATE hr.emphist set salary = salary + 1;
COMMIT;
ALTER SYSTEM SWITCH LOGFILE;
