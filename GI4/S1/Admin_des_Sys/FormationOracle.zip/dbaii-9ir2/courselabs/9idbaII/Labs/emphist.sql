connect system/manager
ALTER USER hr
QUOTA UNLIMITED ON users;
CREATE TABLE hr.emphist 
TABLESPACE users 
AS SELECT * FROM hr.employees
   WHERE department_id = 50;

