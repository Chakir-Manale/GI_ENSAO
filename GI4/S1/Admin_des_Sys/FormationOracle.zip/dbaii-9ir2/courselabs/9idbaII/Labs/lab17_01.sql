@%CLASS_HOME%\STUDENT\LABS\crercts.sql

