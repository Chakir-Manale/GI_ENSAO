REM #############################
REM
REM   CREATED:      02 Apr 2001
REM   UPDATED:      
REM   FILE NAME:    crercts.sql
REM   FILE VERSION: 1.0.0
REM
REM #############################
SPOOL %CLASS_HOME%\ADMIN\CREATE\create_rcts.log
SET ECHO ON
SET TERMOUT ON
CONNECT sys/change_on_install AS SYSDBA

REM ***** Tablespace for the Recovery Catalog *****
CREATE TABLESPACE recat
DATAFILE 'c:\oraclass\ORADATA\u05\recat_01.dbf' SIZE 15M
AUTOEXTEND ON NEXT 1M MAXSIZE 30M
PERMANENT;

REM ***** User/schema for the Recovery Catalog *****
CREATE USER rcuser IDENTIFIED BY rcuser
TEMPORARY TABLESPACE temp
DEFAULT TABLESPACE recat
QUOTA UNLIMITED ON recat;

GRANT connect, resource, recovery_catalog_owner 
TO rcuser;

SPOOL OFF
