drop table hr.emp11;
create table hr.emp11 as select * from hr.employees;

