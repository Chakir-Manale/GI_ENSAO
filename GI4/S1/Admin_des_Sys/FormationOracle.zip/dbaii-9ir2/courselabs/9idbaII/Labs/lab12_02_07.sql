@%CLASS_HOME%\student\labs\breakdb.sql






