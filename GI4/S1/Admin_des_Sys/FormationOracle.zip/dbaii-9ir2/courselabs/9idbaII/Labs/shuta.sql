connect / as sysdba
shutdown abort;
