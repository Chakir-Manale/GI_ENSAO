Rem NAME
Rem   crequerytab.sql
Rem
Rem FUNCTION
Rem   Create and populate tables in the QUERY_DATA tablespace.
Rem
Rem NOTES

REM set feedback off;

ALTER USER hr
QUOTA unlimited ON query_data;

CREATE TABLE hr.employees_hist
TABLESPACE query_data
AS SELECT * FROM hr.employees;

CREATE TABLE hr.departments_hist
TABLESPACE query_data
AS SELECT * FROM hr.departments;

ALTER TABLESPACE query_data READ ONLY;

REM set feedback on
