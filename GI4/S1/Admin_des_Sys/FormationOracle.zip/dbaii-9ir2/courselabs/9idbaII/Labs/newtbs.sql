set echo off
set head off
set feed off
set term off

create tablespace new_users
datafile 'c:\oraclass\oradata\u04\newusers01.dbf' size 500k reuse 
/
ALTER USER hr
QUOTA unlimited ON new_users
/
CREATE TABLE hr.new_emp
TABLESPACE new_users
AS SELECT * FROM hr.employees
/
insert into hr.new_emp
select * from hr.employees
/
commit;
alter system switch logfile
/
insert into hr.new_emp
select * from hr.employees
/
commit;
alter system switch logfile
/
insert into hr.new_emp
select * from hr.employees
/
commit;
alter system switch logfile
/
spool %CLASS_HOME%\STUDENT\LABS\newtbs.cmd

select 'del /q ' || file_name || chr(10) from dba_data_files
where tablespace_name = 'NEW_USERS'
/
spool off

host net stop oracleserviceDBA
host %CLASS_HOME%\STUDENT\labs\sleep 15
host %CLASS_HOME%\STUDENT\LABS\newtbs.cmd
host %CLASS_HOME%\STUDENT\labs\sleep 5
host net start oracleserviceDBA

