set echo off
set termout off
set heading off
set feedback off
set verify off

update hr.emphist set salary = salary * 1.1;

spool wksh05.cmd
select '@echo off' from dual;
select 'net stop OracleServiceDBA' from dual;
select 'sleep 10' from dual;
select 'del /q ' || file_name || chr(10) from dba_data_files
where tablespace_name like upper('%&1%') 
/
select 'sleep 5' from dual;
select 'net start OracleServiceDBA' from dual;

spool off;
exit;

