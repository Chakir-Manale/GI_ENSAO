set echo off
set termout off
set heading off
set feedback off
set verify off

spool wksh02.cmd
select '@echo off' from dual;
select 'net stop oracleServiceDBA' from dual;
select 'sleep 10' from dual;
select 'del /q ' || v$logfile.member from v$logfile where group# = 
( select min(v$log.group#) from v$log where status = 'CURRENT');
select 'sleep 5' from dual;
select 'net start OracleServiceDBA' from dual;

spool off;
exit;

