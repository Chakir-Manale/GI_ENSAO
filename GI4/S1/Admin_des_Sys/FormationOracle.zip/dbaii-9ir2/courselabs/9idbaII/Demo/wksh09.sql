set echo off
set heading off
set feed off
set verify off
set termout off

alter tablespace &1 begin backup;

@moreemphist

connect sys/change_on_install as sysdba

shutdown abort

exit;


