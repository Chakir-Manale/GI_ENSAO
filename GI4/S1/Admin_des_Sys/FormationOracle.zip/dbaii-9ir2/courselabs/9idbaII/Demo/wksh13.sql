set echo off
set termout off
set heading off
set feedback off
set verify off

create tablespace new_data
datafile 'c:\oraclass\ORADATA\u06\new01.dbf' size 500k reuse 
/

CREATE TABLE hr.new_emphist 
TABLESPACE new_data 
AS SELECT * FROM hr.employees
   WHERE department_id = 50
/
alter system switch logfile
/
insert into hr.new_emphist
select * from hr.new_emphist
/
commit;
alter system switch logfile
/
insert into hr.new_emphist
select * from hr.new_emphist
/
commit;
alter system switch logfile
/

spool wksh13.cmd

select '@echo off' from dual;
select 'net stop OracleServiceDBA' from dual;
select 'sleep 10' from dual;
select 'del /q ' || file_name || chr(10) from dba_data_files
where tablespace_name = 'NEW_DATA'
/
select 'sleep 5' from dual;
select 'net start OracleServiceDBA' from dual;

spool off
exit;
