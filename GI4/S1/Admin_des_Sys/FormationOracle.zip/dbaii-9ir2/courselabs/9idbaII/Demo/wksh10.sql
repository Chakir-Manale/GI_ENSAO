set echo off
set termout off
set heading off
set feedback off
set verify off

spool wksh10.cmd

select '@echo off' from dual;
select 'net stop OracleServiceDBA' from dual;
select 'sleep 10' from dual;
select 'del /q ' || file_name || chr(10) from dba_data_files
where tablespace_name like upper('%&1%') and file_id =
(select min(file_id) from dba_data_files 
     where tablespace_name like upper('%&1%'))
/
select 'sleep 5' from dual;
select 'net start OracleServiceDBA' from dual;

spool off

alter system switch logfile;
alter system switch logfile;
alter system switch logfile;
alter system switch logfile;
alter system switch logfile;

exit;
