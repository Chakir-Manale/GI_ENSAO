set echo off
set termout off
set heading off
set feedback off
set verify off

alter system switch logfile;

alter tablespace query_data read write;

insert into hr.departments_hist
select * from hr.departments_hist
/
commit;
alter system switch logfile;

insert into hr.departments_hist
select * from hr.departments_hist
/
commit;
alter system switch logfile;

insert into hr.departments_hist
select * from hr.departments_hist  
/

spool wksh15.cmd

select '@echo off' from dual;
select 'net stop OracleServiceDBA' from dual;
select 'sleep 10' from dual;
select 'del /q ' || name from v$controlfile;
select 'del /q ' || file_name || chr(10) from dba_data_files
where tablespace_name = 'QUERY_DATA';
select 'sleep 5' from dual;
select 'net start OracleServiceDBA' from dual;
spool off
exit;

