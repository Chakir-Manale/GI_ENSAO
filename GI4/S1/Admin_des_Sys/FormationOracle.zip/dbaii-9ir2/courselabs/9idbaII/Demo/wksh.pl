# Copyright 1997 Oracle Corporation
# History: Created 5/15/97 -> sdyer
#          Modified 11/18/97 -> sdyer
#          Modified 3/19/97 -> dorme "Monty Orme"
#          Modified 11/15/99 -> dorme "Monty Orme"
#		Changed $sqlplus and $svrmgr or 8i
####################################################


$sqlplus = "sqlplus -s";
$svrmgr = svrmgrl;
$userpass = "system/manager";
$scenario_file = "scenario.cfg";
$prev_file = "c:\\temp\\prev.tmp";
$class_source=$ENV{class_source};

if ($ARGV[0] != "") {$new_scenario = $ARGV[0]; 
		     goto SWITCH};

######################## Select either a local or remote scenario.cfg file ##########################
# The scenario.cfg can either be local or remote. The default is a remote scenario.cfg on the server.
# Uncomment one of the lines below to select.

# Remote:
#open SCENARIO, "$class_source\\80bur\\setup\\$scenario_file" or die("\nCan't open scenario file $scenario_file: $!. \nCheck that the environment variable CLASS_SOURCE is set.\n");
# Local:
# open SCENARIO, "c:\\temp\\$scenario_file" or die("\nCan't open scenario file $scenario_file: $!. \n");

######################################################################################################

open PREVIOUS, $prev_file; 

$prev_scenario = <PREVIOUS>;

if ($prev_scenario eq "") {$prev_scenario = 0;}

@scenarios = <SCENARIO>;

if ($prev_scenario != 0) {      # Entry in prev.tmp exists
	$i=0;
	while ($scenarios[$i] != $prev_scenario) { 
	$i = $i +1 ;}
	$new_scenario = $scenarios[$i + 1];
	if ($new_scenario eq "") {print "\nNo more scenarios. Congratulations! You're finished.\n"};}
else {$new_scenario = $scenarios[0];} # prev.tmp doesn't exist
		
close PREVIOUS;
open PREVIOUS, ">$prev_file";
print PREVIOUS $new_scenario;   #put the previous scenario in the prev.tmp file

SWITCH: {

	if ($new_scenario == 1) 
	{
	system ("$sqlplus $userpass$connect \@wksh01.sql");
        system ("wksh01.cmd");
	system ("del wksh01.cmd");
	last SWITCH;
	};
	  

	if ($new_scenario == 2) 
	{
	system ("$sqlplus $userpass$connect \@wksh02.sql");
	system ("wksh02.cmd");
	system ("del wksh02.cmd");
	last SWITCH;
	};


	if ($new_scenario == 3)
	{
	system ("$sqlplus $userpass$connect \@wksh03.sql");
	system ("wksh03.cmd");
	system ("del wksh03.cmd");
	last SWITCH;
	};


	if ($new_scenario == 4)
	{
	system ("$sqlplus $userpass$connect \@wksh04.sql");
	system ("wksh04.cmd");
	system ("del wksh04.cmd");
	last SWITCH;
	};


	if ($new_scenario == 5)
	{
	$tablespace = UNDOTBS;
	system ("$sqlplus $userpass$connect \@wksh05.sql $tablespace");
 	system ("wksh05.cmd");	
	system ("del wksh05.cmd");
	last SWITCH;
	};     


	if ($new_scenario == 6)
	{
	$tablespace = SYSTEM;
	system ("$sqlplus $userpass$connect \@wksh06.sql $tablespace");
	system ("wksh06.cmd");
	system ("del wksh06.cmd");
	};


	if ($new_scenario == 7)
	{
	$tablespace = USERS;
	system("$sqlplus $userpass$connect \@wksh07.sql $tablespace");
	system ("wksh07.cmd");
	system ("del wksh07.cmd");
	};
	

	if ($new_scenario == 8)
	{
	$table = "HR.EMPHIST";
	system ("$sqlplus $userpass$connect \@wksh08.sql $table");
	};


	if ($new_scenario == 9)
	{
	$tablespace = USERS;
	system ("$sqlplus $userpass$connect \@wksh09.sql $tablespace");
	};

	if ($new_scenario == 10)
	{
	$tablespace = USERS;
	system ("$sqlplus $userpass$connect \@wksh10.sql $tablespace");       
	system ("wksh10.cmd"); 
	system ("del wksh10.cmd"); 
	};

	if ($new_scenario == 11)
	{
	$tablespace = USERS;
	system ("$sqlplus $userpass$connect \@wksh11.sql $tablespace");    
	system ("wksh11.cmd"); 
	system ("del wksh11.cmd"); 
	};


	if ($new_scenario == 12)
	{
	$tablespace = INDX;
	system ("$sqlplus $userpass$connect \@wksh12.sql $tablespace");
	system ("wksh12.cmd"); 
	system ("del wksh12.cmd");
	};


	if ($new_scenario == 13)
	{
	system ("$sqlplus $userpass$connect \@wksh13.sql");
	system ("wksh13.cmd");
	system ("del wksh13.cmd");
	};


	if ($new_scenario == 14)
	{
	system ("$sqlplus $userpass$connect \@wksh14.sql");   
	system ("wksh14.cmd");
	system ("del wksh14.cmd");  
	};


	if ($new_scenario == 15)
	{
	system ("$sqlplus $userpass$connect \@wksh15.sql");   
	system ("wksh15.cmd"); 
	system ("del wksh15.cmd"); 
	};



	if ($new_scenario == 16)
	{
	system ("$sqlplus $userpass$connect \@wksh16.sql");     
	system ("wksh16.cmd"); 
	system ("del wksh16.cmd");	
	};

	$nothing = 1;

   }