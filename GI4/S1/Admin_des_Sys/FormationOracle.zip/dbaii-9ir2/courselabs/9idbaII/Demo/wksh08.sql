set echo off
set heading off
set feed off
set verify off

drop table &1 cascade constraints
/
exit;
