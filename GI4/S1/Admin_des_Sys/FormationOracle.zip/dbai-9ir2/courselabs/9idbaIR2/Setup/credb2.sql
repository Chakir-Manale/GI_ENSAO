REM #############################
REM
REM   CREATED:      30 Mar 2001
REM   UPDATED:      24 Apr 2001
REM   FILE NAME:    crdb2sid.sql
REM   FILE VERSION: 1.1.3
REM
REM	Modified 01-NOV-01 Monty Orme
REM		For use at OAEC Partner locations and NT On-sites
REM
REM
REM #############################

CONNECT / AS SYSDBA

CREATE USER mdsys IDENTIFIED BY mdsys DEFAULT TABLESPACE system;
@%ORACLE_HOME%\md\admin\mdprivs
@%ORACLE_HOME%\md\admin\mdinst.sql

REM #################################
REM
REM Add Sample Schema Users HR and OE
REM
REM #################################

CONNECT / AS SYSDBA

ALTER USER SYS IDENTIFIED BY ORACLE;

@%ORACLE_HOME%\demo\schema\human_resources\hr_main.sql hr sample temp oracle c:\oraclass\admin\create\

CONNECT / AS SYSDBA

@%ORACLE_HOME%\demo\schema\order_entry\oe_main.sql oe sample temp hr oracle c:\oraclass\admin\create\

SPOOL %CLASS_HOME%\ADMIN\CREATE\credb2.log

SET ECHO ON

CONNECT / AS SYSDBA

execute dbms_utility.analyze_schema('HR','COMPUTE');

ALTER TABLESPACE query_data READ ONLY;

shutdown immediate

create spfile from pfile;

startup 

SPOOL OFF

exit


 
