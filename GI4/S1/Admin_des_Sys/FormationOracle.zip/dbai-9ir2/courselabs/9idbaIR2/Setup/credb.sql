REM ###########################################################################
REM   FILE   : crdbsid.sql
REM   PURPOSE: Uniform database environment in classrooms
REM
REM   CREATED:      28 Feb 2001
REM   UPDATED:      16 Apr 2001
REM   FILE NAME:    crdbsid.sql
REM   FILE VERSION: 1.1.3
REM
REM	Modified 01-NOV-01 Monty Orme
REM		For use at OAEC Partner locations and NT On-sites
REM
REM   The following values may need to be updated accordingly.
REM   DB_NAME     Example db01
REM                The database name - to be same for instance and service names.
REM   PFILE        The PFILE parameter should also be modified for the db_name.
REM   DB FILENAMEs The DB Files need to be renamed with the db_name.   
REM ###########################################################################

SPOOL %CLASS_HOME%\ADMIN\CREATE\credb.log

SET ECHO ON

STARTUP NOMOUNT PFILE=%CLASS_SOURCE%\%CLASS%\setup\initcreate.ora

CREATE DATABASE DBA
   LOGFILE
      GROUP 1 ('c:\oraclass\ORADATA\u03\log01a.rdo') SIZE 10M,
      GROUP 2 ('c:\oraclass\ORADATA\u03\log02a.rdo') SIZE 10M
   MAXLOGFILES 32
   MAXLOGMEMBERS 3 
   MAXLOGHISTORY 1
   DATAFILE 'c:\oraclass\ORADATA\u01\system01.dbf' SIZE 100M
      AUTOEXTEND ON NEXT 5M MAXSIZE 150M 
   UNDO TABLESPACE undotbs
      DATAFILE 'c:\oraclass\ORADATA\u02\undotbs.dbf' SIZE 15M
      AUTOEXTEND ON NEXT 5M MAXSIZE 30M
   DEFAULT TEMPORARY TABLESPACE temp
      TEMPFILE 'c:\oraclass\ORADATA\u02\temp01.dbf' SIZE 15M
      AUTOEXTEND ON NEXT 5M MAXSIZE 30M
   MAXDATAFILES 40
   MAXINSTANCES 1
   CHARACTER SET WE8ISO8859P1
   NATIONAL CHARACTER SET AL16UTF16
;

SPOOL OFF

EXIT
 
