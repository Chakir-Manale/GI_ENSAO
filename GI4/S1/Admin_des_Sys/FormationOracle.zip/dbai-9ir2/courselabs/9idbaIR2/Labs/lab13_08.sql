SET ECHO ON

ALTER SESSION SET CONSTRAINTS=deferred;

INSERT INTO system.orders
  VALUES (800,'01-JAN-98','J01',NULL);

INSERT INTO system.customers
   VALUES ('J01','Sports Store', 'East');

COMMIT;
 
