CONNECT system/manager

INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(610,'11-NOV-97','A01');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(611,'15-NOV-97','A02');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(612,'19-NOV-97','A04');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(601,'05-MAR-97','A06');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(602,'09-APR-97','A02');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(600,'05-MAR-97','A03');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(604,'19-APR-97','A06');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(605,'18-MAY-97','A06');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(607,'22-MAY-97','A04');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(608,'29-MAY-97','A04');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(603,'09-APR-97','A02');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(613,'06-DEC-97','A08');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(614,'06-DEC-97','A02');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(616,'08-DEC-97','A03');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(619,'27-DEC-97','A04');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(617,'10-DEC-97','A05');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(615,'06-DEC-97','A07');    
INSERT INTO system.orders(ord_id,ord_date,cust_code) VALUES(618,'20-DEC-97','A02');    

INSERT INTO system.customers VALUES('A01','TKB SPORT SHOP','West');
INSERT INTO system.customers VALUES('A02','VOLLYRITE','North');
INSERT INTO system.customers VALUES('A03','JUST TENNIS','North');
INSERT INTO system.customers VALUES('A04','EVERY MOUNTAIN','South');
INSERT INTO system.customers VALUES('A05','SHAPE UP','South');
INSERT INTO system.customers VALUES('A06','SHAPE UP','West');
INSERT INTO system.customers VALUES('A07','WOMENS SPORTS','South');
INSERT INTO system.customers VALUES('A08','NORTH WOODS HEALTH AND FITNESS SUPPLY CENTER','East');

COMMIT;

