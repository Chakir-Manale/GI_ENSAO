CONNECT SYSTEM/MANAGER

SET ECHO ON

CREATE TABLE products ( prod_code   NUMBER(6),
                        description VARCHAR2(30),
                        price       NUMBER(8,2)   )
    TABLESPACE data02; 

ALTER TABLE customers
  ADD ( CONSTRAINT customers_cust_code_pk PRIMARY KEY(cust_code)
           DEFERRABLE INITIALLY IMMEDIATE
           USING INDEX TABLESPACE indx,
        CONSTRAINT custmoers_region_ck
           CHECK (region IN ('East', 'West', 'North', 'South'))
      );

ALTER TABLE orders
  ADD ( CONSTRAINT orders_ord_id_pk PRIMARY KEY(ord_id)
           USING INDEX TABLESPACE indx,
        CONSTRAINT orders_cust_code_fk FOREIGN KEY (cust_code)
           REFERENCES customers (cust_code)
           DEFERRABLE INITIALLY IMMEDIATE,
        CONSTRAINT orders_date_of_dely_ck
           CHECK (date_of_dely >= ord_date) 
      );

ALTER TABLE products
 ADD CONSTRAINT products_prod_code_uk UNIQUE (prod_code) 
     DEFERRABLE DISABLE;

