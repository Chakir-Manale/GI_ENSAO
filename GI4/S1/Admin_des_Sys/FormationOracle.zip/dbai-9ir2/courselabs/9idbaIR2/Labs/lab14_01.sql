CONNECT / AS SYSDBA

CREATE USER jeff 
   IDENTIFIED BY superman
   DEFAULT TABLESPACE users
   TEMPORARY TABLESPACE temp
   QUOTA 1M ON users
   QUOTA 1M ON indx;

GRANT connect,resource TO jeff;

