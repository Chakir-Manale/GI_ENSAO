CONNECT hr/hr

INSERT INTO departments (department_id, department_name)
VALUES (9999,'x');
