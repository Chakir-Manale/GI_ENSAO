connect system/manager

INSERT INTO system.products
  VALUES(4000,'UNIX Monitor',3620);


INSERT INTO system.products
  VALUES(4000,'NT Monitor', 2400);

COMMIT;

