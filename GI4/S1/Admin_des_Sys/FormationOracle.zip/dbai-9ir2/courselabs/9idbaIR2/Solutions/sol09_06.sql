CONNECT / AS SYSDBA;

SELECT   tablespace_name,COUNT(*) AS fragments,
         SUM(bytes) AS total,
         MAX(bytes) AS largest
FROM     dba_free_space
GROUP BY tablespace_name;

