SELECT count(*)
FROM   dba_extents
WHERE  segment_name='ORDERS'
AND    owner='SYSTEM';

