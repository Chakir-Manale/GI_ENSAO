CONNECT system/manager

DROP INDEX numb_oe_idx;

DROP INDEX numb_no_idx;

CREATE BITMAP INDEX numb_oe_idx
   ON numbers(odd_even)
   TABLESPACE index01;

CREATE BITMAP INDEX numb_no_idx
   ON numbers(no)
   TABLESPACE index01;

SELECT segment_name, blocks
FROM   dba_segments
WHERE  segment_name LIKE 'NUMB%'
AND    segment_type='INDEX';

