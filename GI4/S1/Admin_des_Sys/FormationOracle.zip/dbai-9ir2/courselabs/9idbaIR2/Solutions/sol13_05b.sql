SELECT constraint_name, table_name, 
       constraint_type, validated, status
FROM   dba_constraints
WHERE  table_name = 'PRODUCTS'
AND    owner='SYSTEM';

