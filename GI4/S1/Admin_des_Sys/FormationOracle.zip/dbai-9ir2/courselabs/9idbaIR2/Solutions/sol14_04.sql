ALTER PROFILE default LIMIT
   FAILED_LOGIN_ATTEMPTS 2
   PASSWORD_LIFE_TIME 30
   PASSWORD_REUSE_TIME 1/1440
   PASSWORD_GRACE_TIME 5;

SELECT resource_name, limit 
FROM   dba_profiles
WHERE  profile='DEFAULT' 
AND    resource_type='PASSWORD';

