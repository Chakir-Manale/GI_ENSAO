CONNECT emi/abcd12;

GRANT select ON customers1 
TO bob WITH GRANT OPTION; 

CONNECT system/manager;

COLUMN grantee    FORMAT a8
COLUMN owner      FORMAT a8
COLUMN table_name FORMAT a10
COLUMN grantor    FORMAT a8
COLUMN privilege  FORMAT a10
COLUMN grantable  FORMAT a3
COLUMN hiearchy   FORMAT a3

SELECT * 
FROM   dba_tab_privs
WHERE  grantee='BOB';

