CONNECT system/manager

COLUMN constraint_name FORMAT a25
COLUMN table_name      FORMAT a10
COLUMN constraint_type FORMAT a1
COLUMN deferrable      FORMAT a15
COLUMN status          FORMAT a10

SELECT constraint_name, table_name, 
       constraint_type, deferrable, status
FROM   dba_constraints
WHERE  table_name IN 
          ('PRODUCTS','ORDERS','CUSTOMERS')
AND owner='SYSTEM';

