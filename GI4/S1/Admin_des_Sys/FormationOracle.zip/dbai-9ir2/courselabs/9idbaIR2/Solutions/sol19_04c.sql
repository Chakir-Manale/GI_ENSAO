
select * from DEPARTMENTS2;