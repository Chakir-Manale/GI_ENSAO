CONNECT emi/"abcd12"

@%CLASS_HOME%\student\labs\lab16_02a.sql

