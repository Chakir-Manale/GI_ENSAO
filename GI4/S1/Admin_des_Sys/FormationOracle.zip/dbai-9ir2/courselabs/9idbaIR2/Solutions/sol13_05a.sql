ALTER TABLE system.products
 ENABLE NOVALIDATE CONSTRAINT products_prod_code_uk;

