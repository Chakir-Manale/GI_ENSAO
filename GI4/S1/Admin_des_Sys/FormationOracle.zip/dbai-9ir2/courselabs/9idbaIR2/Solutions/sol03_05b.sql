CONNECT hr/hr

INSERT INTO regions VALUES (5, 'Mars');


