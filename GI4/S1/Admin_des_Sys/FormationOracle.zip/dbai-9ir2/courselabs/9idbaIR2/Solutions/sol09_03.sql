CONNECT system/manager 

COLUMN segment_name FORMAT a20
COLUMN segment_type FORMAT a15

SELECT segment_name,segment_type,
       max_extents, extents
FROM   dba_segments
WHERE  extents+5 > max_extents
AND    segment_type<>'CACHE';

