connect hr/hr
select * from DEPARTMENTS2;

