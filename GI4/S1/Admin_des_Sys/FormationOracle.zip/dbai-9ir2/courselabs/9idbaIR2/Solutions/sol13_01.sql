CONNECT system/manager

@%CLASS_HOME%\student\labs\lab13_01.sql

