SET ECHO ON

CONNECT emi/abcd12

GRANT select ON customers TO system;

CONNECT system/manager

CREATE VIEW cust_view AS
   SELECT *
   FROM   emi.customers;

