UPDATE  system.products
SET     prod_code='4001'
WHERE   rowid = ( SELECT max(row_id)
                  FROM   exceptions
                  WHERE  table_name='PRODUCTS'
                )
;

