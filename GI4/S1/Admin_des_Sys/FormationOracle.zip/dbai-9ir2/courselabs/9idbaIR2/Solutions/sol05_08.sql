SELECT name 
FROM   v$database;

SELECT instance 
FROM   v$thread;

SELECT value 
FROM   v$parameter
WHERE  name ='db_block_size';

