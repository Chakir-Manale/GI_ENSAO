TRUNCATE TABLE system.customers;

