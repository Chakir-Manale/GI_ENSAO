SELECT file_id, block_id, blocks
FROM   dba_extents
WHERE  segment_name='CUST_REGION_IDX'
AND    owner='SYSTEM';

