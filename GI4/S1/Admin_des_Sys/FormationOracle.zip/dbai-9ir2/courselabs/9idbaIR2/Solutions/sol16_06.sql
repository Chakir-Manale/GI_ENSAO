CONNECT / AS SYSDBA

GRANT sysoper TO emi;

