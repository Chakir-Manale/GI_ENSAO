SELECT segment_name
FROM   dba_rollback_segs
WHERE  tablespace_name = 'UNDOTBS';
 
SELECT a.usn,a.name,b.status
FROM v$rollname a, v$rollstat b
WHERE a.name IN ( SELECT segment_name
                  FROM   dba_segments
                  WHERE  tablespace_name = 'UNDOTBS'
                ) 
AND a.usn = b.usn;

