CONNECT system/manager

ALTER INDEX cust_region_idx REBUILD
  TABLESPACE indx;

