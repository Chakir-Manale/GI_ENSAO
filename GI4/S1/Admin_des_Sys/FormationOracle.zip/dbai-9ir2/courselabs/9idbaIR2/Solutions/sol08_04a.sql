CREATE TABLE table1 ( x CHAR(1))
TABLESPACE ronly;

ALTER TABLESPACE ronly READ ONLY;

SELECT enabled, status, name FROM v$datafile;



