CONNECT / AS SYSDBA

SET ECHO ON

SELECT parameter, value
FROM   nls_database_parameters
WHERE  parameter LIKE '%CHARACTERSET%';

