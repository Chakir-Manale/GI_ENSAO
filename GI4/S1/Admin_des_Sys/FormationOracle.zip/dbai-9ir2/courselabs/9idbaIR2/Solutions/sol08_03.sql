ALTER TABLESPACE index01 OFFLINE;

SELECT name, status
FROM   v$datafile;

host copy %CLASS_HOME%\oradata\u02\index01.dbf %CLASS_HOME%\oradata\u06\index01.dbf


ALTER TABLESPACE index01
   RENAME DATAFILE
   'c:\oraclass\oradata\u02\index01.dbf' TO
   'c:\oraclass\oradata\u06\index01.dbf';

ALTER TABLESPACE index01 ONLINE;

COLUMN name FORMAT a45

SELECT name, status
FROM   v$datafile;
