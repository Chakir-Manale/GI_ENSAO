CONNECT system/manager;

INSERT INTO emi.customers1
   SELECT * 
   FROM   system.customers;

SELECT * FROM emi.customers1;

