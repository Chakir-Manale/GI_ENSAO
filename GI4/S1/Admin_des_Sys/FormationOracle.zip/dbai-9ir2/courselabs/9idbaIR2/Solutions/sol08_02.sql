ALTER DATABASE
DATAFILE 'c:\oraclass\oradata\u03\data02.dbf' RESIZE 1500K;

COLUMN name FORMAT a40

SELECT name, bytes, create_bytes
FROM   v$datafile
WHERE  name LIKE '%DATA02%';

