SELECT member 
FROM   v$logfile;

SELECT group#, members
FROM   v$log;

