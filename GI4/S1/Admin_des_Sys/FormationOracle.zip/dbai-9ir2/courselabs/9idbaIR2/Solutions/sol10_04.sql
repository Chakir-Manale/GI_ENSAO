
ALTER SYSTEM SET undo_tablespace='UNDO2' SCOPE=BOTH;

