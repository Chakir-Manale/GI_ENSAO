connect system/manager

CREATE VIEW cust_view AS 
   SELECT * 
   FROM   emi.customers;

