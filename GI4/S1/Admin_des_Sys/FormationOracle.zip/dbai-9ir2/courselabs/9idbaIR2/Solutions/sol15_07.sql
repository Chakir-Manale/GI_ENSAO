DROP USER emi;

