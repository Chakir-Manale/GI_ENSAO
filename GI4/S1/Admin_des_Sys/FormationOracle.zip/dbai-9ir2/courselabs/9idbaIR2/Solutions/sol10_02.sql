CREATE UNDO TABLESPACE undo2
DATAFILE 'c:\oraclass\oradata\u03\undo2.dbf' size 15M;

SELECT segment_name
FROM   dba_rollback_segs
WHERE  tablespace_name = 'UNDO2';

