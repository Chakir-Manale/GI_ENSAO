ALTER SYSTEM SWITCH LOGFILE;

ALTER DATABASE DROP LOGFILE GROUP 3;

SELECT group#, members 
FROM   v$log;

SHUTDOWN IMMEDIATE

CONNECT / AS SYSDBA

host del %CLASS_HOME%\oradata\u03\log03a.rdo
host del %CLASS_HOME%\oradata\u04\log03b.rdo

STARTUP



