CONNECT system/manager

ALTER USER bob QUOTA 0 ON users;

