connect system/manager

@%CLASS_HOME%\STUDENT\LABS\lab14_01.sql

