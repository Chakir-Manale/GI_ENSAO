COLUMN tablespace_name FORMAT a15
COLUMN user            FORMAT a10

SELECT * 
FROM   dba_ts_quotas 
WHERE username = 'BOB';

