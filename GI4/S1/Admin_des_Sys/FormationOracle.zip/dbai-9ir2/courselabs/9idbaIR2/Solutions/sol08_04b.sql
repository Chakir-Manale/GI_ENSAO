
CREATE TABLE table2 ( y CHAR(1))
TABLESPACE ronly;

DROP TABLE table1;

