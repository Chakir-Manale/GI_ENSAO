SELECT index_name,table_name,uniqueness
FROM   dba_indexes
WHERE  index_name in 
          ( SELECT constraint_name
            FROM   dba_constraints
            WHERE  table_name IN ('PRODUCTS', 'ORDERS', 'CUSTOMERS')
            AND    owner='SYSTEM'
            AND    constraint_type in ('P','U')
          )
;

