connect hr/hr

create table employees2
as select * from employees;

truncate table employees2;

select * from employees2;
		
