SET ECHO ON

CONNECT system/manager

ALTER PROFILE default LIMIT
   FAILED_LOGIN_ATTEMPTS     UNLIMITED            
   PASSWORD_LIFE_TIME        UNLIMITED               
   PASSWORD_REUSE_TIME       UNLIMITED              
   PASSWORD_REUSE_MAX        UNLIMITED               
   PASSWORD_VERIFY_FUNCTION  NULL         
   PASSWORD_LOCK_TIME        UNLIMITED               
   PASSWORD_GRACE_TIME       UNLIMITED;

