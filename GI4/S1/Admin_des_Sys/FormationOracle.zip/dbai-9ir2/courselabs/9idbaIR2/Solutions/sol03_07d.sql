SELECT *
FROM   regions;


