SELECT log_mode 
FROM   v$database;

SELECT archiver 
FROM   v$instance;

