SELECT tablespace_name from dba_tablespaces;

