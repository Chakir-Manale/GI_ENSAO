CONNECT system/manager

GRANT dev, resource TO bob;

ALTER USER bob
   DEFAULT ROLE resource;
   
