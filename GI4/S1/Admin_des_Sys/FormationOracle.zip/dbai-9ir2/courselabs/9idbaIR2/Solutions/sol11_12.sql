CONNECT system/manager

DROP TABLE orders2;

