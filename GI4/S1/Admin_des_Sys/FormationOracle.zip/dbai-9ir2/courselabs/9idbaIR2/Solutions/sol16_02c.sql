GRANT select ON emi.customers1 TO bob;

