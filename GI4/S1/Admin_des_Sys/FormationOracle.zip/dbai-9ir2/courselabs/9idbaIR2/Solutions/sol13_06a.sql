CONNECT system/manager

@?/rdbms/admin/utlexcpt 

