COLUMN username             FORMAT a10
COLUMN default_tablespace   FORMAT a20
COLUMN temporary_tablespace FORMAT a15

SELECT username, default_tablespace, 
       temporary_tablespace
FROM   dba_users
WHERE  username IN ('BOB', 'EMI');

