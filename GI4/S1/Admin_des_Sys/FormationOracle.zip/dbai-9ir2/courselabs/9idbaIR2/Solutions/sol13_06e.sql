TRUNCATE TABLE exceptions;

ALTER TABLE system.products
   ENABLE CONSTRAINT products_prod_code_uk
   EXCEPTIONS INTO system.exceptions;

