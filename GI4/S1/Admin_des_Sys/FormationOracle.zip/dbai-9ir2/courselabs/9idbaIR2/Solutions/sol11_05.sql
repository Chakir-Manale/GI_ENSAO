CONNECT system/manager

ALTER TABLE orders ALLOCATE EXTENT;

SELECT count(*)
FROM   dba_extents
WHERE  segment_name='ORDERS'
AND    owner='SYSTEM';

