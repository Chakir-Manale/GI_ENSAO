connect system/manager

CREATE ROLE dev;

GRANT create table, create view TO dev;

CONNECT emi/abcd12

GRANT select ON customers to dev;

CONNECT system/manager



