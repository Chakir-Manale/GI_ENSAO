
SELECT count(DISTINCT no) NO,
       count(DISTINCT odd_even) OE
FROM   numbers;

