CONNECT emi/abcd12;

REVOKE select ON customers FROM bob;

