CONNECT system/manager

SELECT DISTINCT f.file_name
FROM   dba_extents e,dba_data_files f
WHERE  e.segment_name='EMP'
AND    e.file_id=f.file_id;

