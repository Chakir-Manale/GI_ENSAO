SELECT username, created 
FROM   dba_users;

