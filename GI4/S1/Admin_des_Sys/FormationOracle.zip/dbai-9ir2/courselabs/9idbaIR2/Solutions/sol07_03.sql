ALTER DATABASE ADD LOGFILE MEMBER
'c:\oraclass\oradata\u04\log01b.rdo' to Group 1,
'c:\oraclass\oradata\u04\log02b.rdo' to Group 2;

COLUMN GROUP# FORMAT 99
COLUMN MEMBER FORMAT a40

SELECT * 
FROM   v$logfile;

