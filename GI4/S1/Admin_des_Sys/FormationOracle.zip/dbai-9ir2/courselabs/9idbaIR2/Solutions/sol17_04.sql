CONNECT bob/aaron$1

SET ROLE select_catalog_role;

SELECT segment_name
FROM   dba_rollback_segs
WHERE  status='ONLINE';

