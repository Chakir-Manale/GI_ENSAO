CONNECT pm/pm;
GRANT hr_role TO sh;