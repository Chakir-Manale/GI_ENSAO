SET ECHO ON
select * from dual;
SET ECHO OFF




