SELECT name
FROM   v$controlfile;

