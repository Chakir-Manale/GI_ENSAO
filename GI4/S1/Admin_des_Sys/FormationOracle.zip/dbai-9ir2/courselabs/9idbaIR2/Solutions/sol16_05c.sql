CONNECT trevor/diamond1$

SELECT * 
FROM emi.customers;

