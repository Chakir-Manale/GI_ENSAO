ALTER SYSTEM SET DB_CREATE_FILE_DEST='c:\oraclass\oradata\u05' SCOPE=MEMORY;

CREATE TABLESPACE data03
DATAFILE SIZE 5M;

SELECT *                   
FROM   v$tablespace;

HOST DIR %CLASS_HOME%\oradata\u05

