DROP TABLESPACE undotbs;

