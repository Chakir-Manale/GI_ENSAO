ALTER USER jeff
   IDENTIFIED BY super1$;

