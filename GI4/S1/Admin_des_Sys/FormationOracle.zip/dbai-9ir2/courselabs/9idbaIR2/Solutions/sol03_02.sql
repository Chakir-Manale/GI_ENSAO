connect / as sysdba
create spfile from pfile;



