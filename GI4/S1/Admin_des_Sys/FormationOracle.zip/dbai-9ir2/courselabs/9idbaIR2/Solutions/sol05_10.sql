SELECT file_name
FROM   dba_data_files
WHERE  tablespace_name = 'SYSTEM';

