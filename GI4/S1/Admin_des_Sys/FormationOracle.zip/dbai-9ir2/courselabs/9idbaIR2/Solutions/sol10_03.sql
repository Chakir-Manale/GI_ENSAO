CONNECT system/manager

@%CLASS_HOME%\student\labs\lab10_03.sql

