CONNECT system/manager

COLUMN privilege FORMAT a20
COLUMN grantee   FORMAT a10

SELECT  *
  FROM  dba_sys_privs
  WHERE grantee = 'RESOURCE';

