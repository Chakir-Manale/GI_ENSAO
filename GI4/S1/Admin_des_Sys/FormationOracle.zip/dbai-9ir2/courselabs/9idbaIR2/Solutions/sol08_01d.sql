
CREATE TABLESPACE ronly
DATAFILE 'c:\oraclass\oradata\u01\ronly01.dbf' SIZE 1M;



