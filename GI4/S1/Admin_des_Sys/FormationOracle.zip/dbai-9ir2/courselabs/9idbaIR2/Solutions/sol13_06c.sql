SELECT rowid, prod_code, description
FROM   system.products
WHERE  rowid IN ( SELECT row_id
                  FROM   exceptions
                  WHERE  table_name='PRODUCTS'
                )
;

