CONNECT system/manager

@%CLASS_HOME%\student\labs\lab09_05.sql

