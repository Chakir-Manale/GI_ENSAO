CONNECT / as sysdba

SET ECHO ON

SELECT username, account_status
FROM   dba_users;

ALTER USER jeff
   ACCOUNT UNLOCK;


CONNECT jeff/super1$

