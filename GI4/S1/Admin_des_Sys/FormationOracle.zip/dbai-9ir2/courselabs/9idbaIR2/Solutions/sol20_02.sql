SELECT   value
FROM     v$nls_valid_values
WHERE    parameter = 'CHARACTERSET'
ORDER BY value;

