ALTER DATABASE ADD LOGFILE
   GROUP 3( 'c:\oraclass\oradata\u03\log03a.rdo',
            'c:\oraclass\oradata\u04\log03b.rdo'
          ) SIZE 1024K,
   GROUP 4( 'c:\oraclass\oradata\u03\log04a.rdo',
            'c:\oraclass\oradata\u04\log04b.rdo'
          ) SIZE 1024K
;

SELECT group#, status 
FROM   v$log;

ALTER SYSTEM SWITCH LOGFILE;

ALTER SYSTEM SWITCH LOGFILE;

ALTER DATABASE DROP LOGFILE GROUP 1, GROUP 2;

SELECT group#, bytes 
FROM   v$log;


