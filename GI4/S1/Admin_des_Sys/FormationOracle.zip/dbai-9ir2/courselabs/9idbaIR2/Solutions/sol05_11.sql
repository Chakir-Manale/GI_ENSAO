SELECT sum(bytes)/1024 "free space in KB"
FROM   dba_free_space;

SELECT sum(bytes)/1024 "used space in KB"
FROM   dba_segments;

