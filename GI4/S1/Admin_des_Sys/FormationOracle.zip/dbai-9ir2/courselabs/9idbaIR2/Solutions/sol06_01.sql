COL name FORMAT a50

SELECT * 
FROM   v$controlfile;

