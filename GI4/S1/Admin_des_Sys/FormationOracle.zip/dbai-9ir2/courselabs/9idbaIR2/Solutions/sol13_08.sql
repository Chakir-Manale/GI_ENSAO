CONNECT system/manager

@%CLASS_HOME%\student\labs\lab13_08.sql

