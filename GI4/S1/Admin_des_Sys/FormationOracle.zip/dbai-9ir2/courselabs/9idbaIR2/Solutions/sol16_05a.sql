CONNECT bob/olink

GRANT select ON emi.customers TO trevor;

