CONNECT system/manager

CREATE INDEX cust_name_idx
   ON customers(name)
  TABLESPACE index01;

CREATE BITMAP INDEX cust_region_idx
  ON system.customers(region)
  TABLESPACE index01;

