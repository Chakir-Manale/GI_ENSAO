CONNECT system/manager

TRUNCATE TABLE orders REUSE STORAGE;

SELECT count(*)
FROM   dba_extents
WHERE  segment_name='ORDERS'
AND    owner='SYSTEM';

