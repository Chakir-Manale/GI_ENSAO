connect system/manager;

GRANT select_catalog_role TO bob;

