CONNECT system/manager

SELECT DISTINCT segment_type
FROM   dba_segments;

