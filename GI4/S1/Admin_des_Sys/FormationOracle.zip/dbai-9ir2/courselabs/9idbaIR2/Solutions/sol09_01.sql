CONNECT system/manager

@%CLASS_HOME%\student\labs\lab09_01.sql

