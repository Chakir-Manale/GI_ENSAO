connect bob/crusader;

ALTER USER bob
TEMPORARY TABLESPACE users;
