CONNECT / AS SYSDBA

SELECT segment_name
FROM   dba_rollback_segs
WHERE  tablespace_name = 'UNDOTBS';

