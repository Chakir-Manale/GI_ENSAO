connect / as sysdba
@?/rdbms/admin/utlpwdmg
