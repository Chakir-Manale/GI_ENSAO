SELECT name 
FROM   v$datafile;

