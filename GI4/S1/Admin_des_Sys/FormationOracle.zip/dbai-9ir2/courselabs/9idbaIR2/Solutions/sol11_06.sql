CONNECT system/manager

CREATE TABLE orders2
   TABLESPACE users
   STORAGE(MINEXTENTS 10)
   AS
   SELECT * FROM orders;

SELECT count(*)
FROM   dba_extents
WHERE  segment_name='ORDERS2'
AND    owner='SYSTEM';

