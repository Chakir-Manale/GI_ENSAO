INSERT INTO system.products
  VALUES(4000,'Monitor',3000); 

