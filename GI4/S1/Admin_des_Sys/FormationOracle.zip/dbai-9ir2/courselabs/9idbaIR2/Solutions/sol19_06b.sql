alter session enable parallel dml;

insert /*+ parallel(employees2,2) */
into employees2 nologging
select * from employees;

commit;

select employee_id, first_name, last_name from employees2;



		
