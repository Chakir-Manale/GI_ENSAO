connect sys/oracle as sysdba;
SELECT s.segment_name,s.segment_type,s.tablespace_name,s.next_extent
FROM dba_segments s
WHERE NOT EXISTS (SELECT 1 
                        FROM dba_free_space f
                        WHERE s.tablespace_name=f.tablespace_name
                        HAVING max(f.bytes) > s.next_extent)
/
