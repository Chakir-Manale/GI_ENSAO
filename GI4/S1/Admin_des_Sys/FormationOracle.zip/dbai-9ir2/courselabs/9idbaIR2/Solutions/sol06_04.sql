SELECT records_total
FROM   v$controlfile_record_section
WHERE  type = 'DATAFILE';

