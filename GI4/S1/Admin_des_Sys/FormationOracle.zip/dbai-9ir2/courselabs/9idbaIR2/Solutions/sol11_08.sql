CONNECT system/manager

TRUNCATE TABLE orders2;

SELECT count(*)
FROM   dba_extents
WHERE  segment_name='ORDERS2'
AND    owner='SYSTEM';

