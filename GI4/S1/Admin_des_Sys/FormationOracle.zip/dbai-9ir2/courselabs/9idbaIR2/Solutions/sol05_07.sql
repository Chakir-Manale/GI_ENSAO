CONNECT / AS SYSDBA

SELECT table_name
FROM   dictionary;

