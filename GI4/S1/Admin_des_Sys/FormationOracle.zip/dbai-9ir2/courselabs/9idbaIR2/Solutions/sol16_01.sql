CONNECT system/manager

CREATE USER emi
  IDENTIFIED BY "abcd12"
  DEFAULT TABLESPACE data01
  TEMPORARY TABLESPACE temp
  QUOTA 1M ON data01;

GRANT create session, create table TO emi;

