truncate table employees2;

select * from employees2;



		
