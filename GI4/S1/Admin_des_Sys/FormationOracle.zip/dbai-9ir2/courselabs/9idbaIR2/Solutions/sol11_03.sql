CONNECT system/manager

SELECT file_id, block_id, blocks
FROM   dba_extents
WHERE  owner = 'SYSTEM'
AND    segment_name = 'ORDERS'
AND    segment_type = 'TABLE';

