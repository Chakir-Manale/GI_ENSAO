CONNECT system/manager

@%CLASS_HOME%\student\labs\lab11_02.sql

