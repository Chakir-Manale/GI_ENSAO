connect bob/crusader; 

ALTER USER bob
IDENTIFIED BY sam;
