CONNECT system/manager

@%CLASS_HOME%\student\labs\lab13_07.sql

