CONNECT system/manager

@%CLASS_HOME%\student\labs\lab11_09.sql

