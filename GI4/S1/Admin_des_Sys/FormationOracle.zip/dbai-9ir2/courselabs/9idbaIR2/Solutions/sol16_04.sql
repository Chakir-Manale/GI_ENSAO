CONNECT system/manager

CREATE USER trevor IDENTIFIED BY "diamond1$";
GRANT create session TO trevor;

