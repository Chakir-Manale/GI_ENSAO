CONNECT / AS SYSDBA

SHUTDOWN IMMEDIATE

HOST del %ORACLE_HOME%\database\spfiledba.ora

CREATE SPFILE='spfiledba.ora'
FROM    PFILE='initDBA.ora';

STARTUP

