CONNECT system/manager

DESCRIBE orders2;

ALTER TABLE orders2
   SET UNUSED COLUMN date_of_dely
   CASCADE CONSTRAINTS;

DESCRIBE orders2;

