ALTER DATABASE ADD 
   LOGFILE GROUP 3(
                    'c:\oraclass\oradata\u03\log03a.rdo',
                    'c:\oraclass\oradata\u04\log03b.rdo'
                  ) SIZE 1024K;

COLUMN GROUP# FORMAT 99
COLUMN MEMBER FORMAT a40

SELECT * 
FROM   v$logfile;

SELECT group#, members 
FROM   v$log;

